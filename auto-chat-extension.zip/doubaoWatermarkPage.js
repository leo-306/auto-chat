"use strict";
(() => {
  // src/doubaoWatermark.ts
  var RAW_TEMPLATE = /~tplv-[^?#~]*image_raw[^?#~]*/;
  var WATERMARK_TEMPLATE = /~tplv-[^?#~]*(?:(?:image|img)_(?:pre|dld)_watermark|downsize_watermark|hcg_watermark|img_pre_mark|(?:ds|hcg|i_(?:pre|dld))_wm|unpaid_image_raw_dld)[^?#~]*/;
  var GENERATED_IMAGE_PATH = /\/rc_gen_image\/[^?#\s"'{}[\]]+/i;
  var IMAGE_KEY = /\/rc_gen_image\/([^/?#~]+\.(?:jpe?g|png|webp))/i;
  var TEMPLATE_SEGMENT = /~tplv-([a-z0-9]+)-[^?#~]+/i;
  var RAW_URL_FIELDS = ["image_raw", "image_raw_b", "raw", "raw_url", "origin", "original", "original_url"];
  var DERIVED_IMAGE_FIELDS = ["image_ori", "image_thumb", "image_thumbnail", "thumbnail", "detail"];
  function isUrlLike(value) {
    if (value.trim() !== value) return false;
    if (/[\s"'{}[\]]/.test(value)) return false;
    return /^(?:https?:)?\/\//.test(value) || value.startsWith("data:image/");
  }
  function isGeneratedImageUrl(value) {
    return GENERATED_IMAGE_PATH.test(value);
  }
  function isWatermarkedImageUrl(value) {
    return WATERMARK_TEMPLATE.test(value);
  }
  function isRawImageUrl(value) {
    return !WATERMARK_TEMPLATE.test(value) && RAW_TEMPLATE.test(value);
  }
  function doubaoImageKey(value) {
    return value.match(IMAGE_KEY)?.[1] ?? null;
  }
  function swapToRawTemplate(value) {
    if (!isWatermarkedImageUrl(value)) return null;
    const swapped = value.replace(TEMPLATE_SEGMENT, (_match, hash) => `~tplv-${hash}-image_raw_b.png`);
    return swapped === value ? null : swapped;
  }
  function jsonMayContainImageUrls(text) {
    return typeof text === "string" && (text.includes("image_raw") || text.includes("image_ori") || text.includes("watermark"));
  }
  var DoubaoRawImageIndex = class {
    rawByKey = /* @__PURE__ */ new Map();
    get size() {
      return this.rawByKey.size;
    }
    record(value) {
      if (!isUrlLike(value) || !isRawImageUrl(value)) return false;
      const key = doubaoImageKey(value);
      if (!key) return false;
      this.rawByKey.set(key, value);
      return true;
    }
    rawFor(value) {
      const key = doubaoImageKey(value);
      return key && this.rawByKey.get(key) || null;
    }
    // 拿到干净原图地址：优先用接口给的，其次自己换模板名。返回 null 表示这个
    // URL 本来就不是需要处理的水印图。
    cleanUrlFor(value) {
      if (!isUrlLike(value)) return null;
      if (isRawImageUrl(value)) return value;
      if (isWatermarkedImageUrl(value)) return this.rawFor(value) ?? swapToRawTemplate(value);
      if (isGeneratedImageUrl(value)) return this.rawFor(value);
      return null;
    }
    rewrite(value) {
      if (!value) return value;
      return this.cleanUrlFor(value) ?? value;
    }
    // 先收集原图地址再改写：同一个响应里原图字段和水印地址常常并排出现，
    // 分两遍走才能保证改写时表已经建好。
    absorb(value) {
      this.harvest(value);
      this.rewriteTree(value);
    }
    harvest(value) {
      const seen = /* @__PURE__ */ new WeakSet();
      const walk = (node) => {
        if (typeof node === "string") {
          this.record(node);
          return;
        }
        if (!isObject(node) || seen.has(node)) return;
        seen.add(node);
        const raw = this.rawFieldUrl(node);
        if (raw) this.record(raw);
        for (const child of Object.values(node)) walk(child);
      };
      walk(value);
    }
    rewriteTree(value) {
      const seen = /* @__PURE__ */ new WeakSet();
      const walk = (node) => {
        if (!isObject(node) || seen.has(node)) return;
        seen.add(node);
        this.pointFieldsAtRaw(node);
        if (isObject(node.image)) this.pointFieldsAtRaw(node.image);
        if (Array.isArray(node)) {
          node.forEach((item, index2) => {
            if (typeof item === "string") node[index2] = this.rewrite(item);
            else walk(item);
          });
          return;
        }
        for (const [key, child] of Object.entries(node)) {
          if (typeof child === "string") node[key] = this.rewrite(child);
          else walk(child);
        }
      };
      walk(value);
    }
    // 这个对象自带原图字段时，把它的主 url 和缩略字段一起指向原图。
    pointFieldsAtRaw(node) {
      const raw = this.rawFieldUrl(node);
      if (!raw) return;
      this.record(raw);
      for (const field of DERIVED_IMAGE_FIELDS) {
        const derived = node[field];
        if (isObject(derived) && typeof derived.url === "string") derived.url = raw;
      }
      if (typeof node.url === "string") node.url = raw;
    }
    rawFieldUrl(node) {
      for (const field of RAW_URL_FIELDS) {
        const value = node[field];
        const url = typeof value === "string" ? value : isObject(value) && typeof value.url === "string" ? value.url : null;
        if (url && isRawImageUrl(url)) return url;
      }
      return null;
    }
  };
  function isObject(value) {
    return typeof value === "object" && value !== null;
  }

  // src/doubaoWatermarkPage.ts
  var INSTALL_FLAG = "__autoChatDoubaoWatermarkInstalled__";
  var DOWNLOAD_WINDOW_MS = 4e3;
  var index = new DoubaoRawImageIndex();
  var canvasSources = /* @__PURE__ */ new WeakMap();
  var downloadWindowUntil = 0;
  var sweepScheduled = false;
  install();
  function install() {
    const scope = window;
    if (scope[INSTALL_FLAG]) return;
    scope[INSTALL_FLAG] = true;
    const nativeFetch = window.fetch;
    hookJsonParse();
    hookFetch(nativeFetch);
    hookXhrOpen();
    hookCanvas(nativeFetch);
    document.addEventListener("click", () => {
      downloadWindowUntil = Date.now() + DOWNLOAD_WINDOW_MS;
      sweepDom();
    }, true);
    scheduleSweep();
  }
  function hookJsonParse() {
    const nativeParse = JSON.parse;
    JSON.parse = ((text, reviver) => {
      const parsed = nativeParse.call(JSON, text, reviver);
      if (!jsonMayContainImageUrls(text)) return parsed;
      try {
        if (typeof parsed === "string") return index.rewrite(parsed);
        index.absorb(parsed);
        scheduleSweep();
      } catch {
      }
      return parsed;
    });
  }
  function hookFetch(nativeFetch) {
    window.fetch = ((input, init) => nativeFetch.call(window, rewriteRequestInput(input), init));
  }
  function rewriteRequestInput(input) {
    if (typeof input === "string" || input instanceof URL) return rewriteUrlValue(input);
    const rewritten = index.rewrite(input.url);
    return rewritten === input.url ? input : new Request(rewritten, input);
  }
  function rewriteUrlValue(url) {
    if (typeof url === "string") return index.rewrite(url);
    const rewritten = index.rewrite(url.href);
    return rewritten === url.href ? url : new URL(rewritten);
  }
  function hookXhrOpen() {
    const nativeOpen = XMLHttpRequest.prototype.open;
    const open = function(method, url, ...rest) {
      nativeOpen.call(this, method, rewriteUrlValue(url), ...rest);
    };
    XMLHttpRequest.prototype.open = open;
  }
  function hookCanvas(nativeFetch) {
    const nativeDrawImage = CanvasRenderingContext2D.prototype.drawImage;
    CanvasRenderingContext2D.prototype.drawImage = function(...args) {
      try {
        const source = args[0];
        const url = source instanceof HTMLImageElement ? source.currentSrc || source.src : source instanceof HTMLCanvasElement ? canvasSources.get(source) : void 0;
        if (url && isGeneratedImageUrl(url)) canvasSources.set(this.canvas, url);
      } catch {
      }
      return nativeDrawImage.apply(this, args);
    };
    const nativeToBlob = HTMLCanvasElement.prototype.toBlob;
    HTMLCanvasElement.prototype.toBlob = function(callback, type, quality) {
      const source = canvasSources.get(this);
      const clean = source && Date.now() < downloadWindowUntil ? index.cleanUrlFor(source) : null;
      if (!clean) {
        nativeToBlob.call(this, callback, type, quality);
        return;
      }
      const fallback = () => nativeToBlob.call(this, callback, type, quality);
      nativeFetch.call(window, clean).then((response) => {
        if (!response.ok) throw new Error(`clean image fetch failed: ${response.status}`);
        return response.blob();
      }).then((blob) => callback(blob)).catch(fallback);
    };
  }
  function scheduleSweep() {
    if (sweepScheduled) return;
    sweepScheduled = true;
    window.setTimeout(() => {
      sweepScheduled = false;
      sweepDom();
    }, 0);
  }
  function sweepDom() {
    for (const image of document.querySelectorAll("img")) {
      const rewritten = index.rewrite(image.src);
      if (rewritten !== image.src) image.src = rewritten;
    }
    for (const element of document.querySelectorAll("img[srcset], source[srcset]")) {
      const rewritten = rewriteSrcset(element.srcset);
      if (rewritten !== element.srcset) element.srcset = rewritten;
    }
    for (const anchor of document.querySelectorAll("a[href]")) {
      const rewritten = index.rewrite(anchor.href);
      if (rewritten !== anchor.href) anchor.href = rewritten;
    }
  }
  function rewriteSrcset(srcset) {
    return srcset.split(",").map((candidate) => {
      const trimmed = candidate.trim();
      if (!trimmed) return candidate;
      const [url, ...descriptors] = trimmed.split(/\s+/);
      const rewritten = index.rewrite(url);
      return rewritten === url ? candidate : [rewritten, ...descriptors].join(" ");
    }).join(", ");
  }
})();
//# sourceMappingURL=doubaoWatermarkPage.js.map
