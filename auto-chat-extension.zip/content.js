"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message = "Required";
        } else {
          message = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message = `Invalid ${issue.validation}`;
        } else {
          message = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message = "Number must be finite";
        break;
      default:
        message = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message };
  };
  var en_default = errorMap;

  // ../../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
  })(errorUtil || (errorUtil = {}));

  // ../../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message) {
      const getIssueProperties = (val) => {
        if (typeof message === "string" || typeof message === "undefined") {
          return { message };
        } else if (typeof message === "function") {
          return message(val);
        } else {
          return message;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    base64url(message) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message) {
      return this._addCheck({ kind: "date", message });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    endsWith(value, message) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    min(minLength, message) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message)
      });
    }
    max(maxLength, message) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message)
      });
    }
    length(len, message) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message) {
      return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message)
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    finite(message) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message)
      });
    }
    safe(message) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    max(maxDate, message) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message) }
      });
    }
    max(maxLength, message) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message) }
      });
    }
    length(len, message) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message) }
      });
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message) }
      });
    }
    max(maxSize, message) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message) }
      });
    }
    size(size, message) {
      return this.min(size, message).max(size, message);
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = /* @__PURE__ */ Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: ((arg) => ZodString.create({ ...arg, coerce: true })),
    number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
    boolean: ((arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    })),
    bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
    date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
  };
  var NEVER = INVALID;

  // ../../packages/shared/dist/index.js
  var JOB_STATUSES = [
    "queued",
    "opening_tab",
    "waiting_chat_ready",
    "uploading",
    "waiting_upload_ready",
    "sending_prompt",
    "waiting_generation",
    "stalled",
    "refreshing",
    "collecting_outputs",
    "downloading",
    "done",
    "failed_retryable",
    "failed_final",
    "needs_manual"
  ];
  var JobStatusSchema = external_exports.enum(JOB_STATUSES);
  var JobModeSchema = external_exports.enum(["image", "text", "video"]);
  var JobPlatformSchema = external_exports.enum(["gpt", "gemini", "doubao"]);
  var ConfigSchema = external_exports.object({
    maxConcurrency: external_exports.number().int().min(1).max(8).default(1),
    stallTimeoutMs: external_exports.number().int().min(3e4).default(3e5),
    hardTimeoutMs: external_exports.number().int().min(6e4).default(9e5),
    maxRefreshPerJob: external_exports.number().int().min(0).max(10).default(2),
    expectedImageCount: external_exports.number().int().min(1).max(12).default(4),
    chatgptUrl: external_exports.string().url().default("https://chatgpt.com/"),
    geminiUrl: external_exports.string().url().default("https://gemini.google.com/app"),
    doubaoUrl: external_exports.string().url().default("https://www.doubao.com/chat/"),
    webhookUrls: external_exports.array(external_exports.string().url()).default([]),
    autoRetry: external_exports.boolean().default(false),
    maxRetries: external_exports.number().int().min(1).max(10).optional()
  }).superRefine((value, ctx) => {
    if (value.autoRetry && value.maxRetries === void 0) {
      ctx.addIssue({
        code: external_exports.ZodIssueCode.custom,
        path: ["maxRetries"],
        message: "maxRetries is required when autoRetry is enabled."
      });
    }
  });
  var CreateJobSchema = external_exports.object({
    id: external_exports.string().min(1).optional(),
    platform: JobPlatformSchema.default("gpt"),
    mode: JobModeSchema.default("image"),
    prompt: external_exports.string().min(1),
    prompts: external_exports.array(external_exports.string().min(1)).optional(),
    expectedImageCount: external_exports.number().int().min(0).max(12).optional(),
    sourceImages: external_exports.array(external_exports.string()).default([]),
    metadata: external_exports.record(external_exports.unknown()).default({}),
    persistTab: external_exports.boolean().default(false),
    parentJobId: external_exports.string().min(1).optional(),
    outputDir: external_exports.string().min(1).optional()
  }).superRefine((value, ctx) => {
    if ((value.mode ?? "image") === "image" && value.expectedImageCount === 0) {
      ctx.addIssue({
        code: external_exports.ZodIssueCode.custom,
        path: ["expectedImageCount"],
        message: "Image jobs must expect at least one image."
      });
    }
  });
  var UpdateStatusSchema = external_exports.object({
    status: JobStatusSchema,
    tabId: external_exports.number().int().optional(),
    conversationUrl: external_exports.string().url().optional(),
    errorMessage: external_exports.string().optional(),
    refreshCount: external_exports.number().int().min(0).optional(),
    workerId: external_exports.string().optional()
  });
  var EventSchema = external_exports.object({
    type: external_exports.string().min(1),
    message: external_exports.string().optional(),
    payload: external_exports.record(external_exports.unknown()).default({})
  });
  var ArtifactSchema = external_exports.object({
    kind: external_exports.enum(["output", "text_output", "source", "screenshot", "log"]),
    filename: external_exports.string().min(1),
    contentType: external_exports.string().min(1).default("application/octet-stream"),
    dataBase64: external_exports.string().min(1)
  });
  var JobSchema = external_exports.object({
    id: external_exports.string(),
    platform: JobPlatformSchema,
    mode: JobModeSchema,
    status: JobStatusSchema,
    prompt: external_exports.string(),
    expectedImageCount: external_exports.number().int().min(0),
    sourceImages: external_exports.array(external_exports.string()),
    metadata: external_exports.record(external_exports.unknown()),
    conversationUrl: external_exports.string().nullable(),
    tabId: external_exports.number().nullable(),
    attempt: external_exports.number().int(),
    refreshCount: external_exports.number().int(),
    errorMessage: external_exports.string().nullable(),
    workerId: external_exports.string().nullable(),
    outputFiles: external_exports.array(external_exports.string()),
    textOutputFile: external_exports.string().nullable(),
    screenshotFiles: external_exports.array(external_exports.string()),
    persistTab: external_exports.boolean(),
    parentJobId: external_exports.string().nullable(),
    outputDir: external_exports.string().nullable(),
    copiedOutputFiles: external_exports.array(external_exports.string()),
    createdAt: external_exports.string(),
    updatedAt: external_exports.string()
  });
  var ClaimJobSchema = external_exports.object({
    workerId: external_exports.string().min(1),
    platform: JobPlatformSchema.default("gpt"),
    jobId: external_exports.string().min(1).optional(),
    runningJobIds: external_exports.array(external_exports.string()).default([])
  });
  var DispatchStateSchema = external_exports.object({
    id: external_exports.number().int().min(0),
    token: external_exports.string().min(1).nullable().default(null),
    platform: JobPlatformSchema.nullable().default(null),
    jobId: external_exports.string().nullable().default(null),
    requestedAt: external_exports.string().nullable()
  });
  function buildGeminiOutputPrompt(prompt, outputIndex, prompts) {
    const explicitPrompt = prompts?.[outputIndex - 1]?.trim();
    const imagePrompt = explicitPrompt || extractImagePrompt(prompt, outputIndex);
    const globalConstraints = extractGeminiGlobalConstraints(prompt);
    const jobId = extractJobId(prompt);
    return [
      jobId && !imagePrompt.includes(`JOB_ID: ${jobId}`) ? `JOB_ID: ${jobId}` : "",
      imagePrompt,
      globalConstraints,
      "\u751F\u6210\u8FD9\u5F20\u56FE\u7247\u3002",
      imagePrompt.includes("JOB_OUTPUT_INDEX:") ? "" : `JOB_OUTPUT_INDEX: ${outputIndex}`
    ].filter(Boolean).join("\n\n");
  }
  function extractJobId(prompt) {
    return prompt.match(/JOB_ID:\s*([^\s]+)/)?.[1] ?? null;
  }
  function extractImagePrompt(prompt, outputIndex) {
    const normalized = prompt.trim();
    const marker = new RegExp(`\u56FE\\s*${outputIndex}\\s*[\uFF1A:=]?`, "u");
    const markerMatch = marker.exec(normalized);
    if (!markerMatch)
      return normalized;
    const start = markerMatch.index + markerMatch[0].length;
    const nextMarker = new RegExp(`\u56FE\\s*${outputIndex + 1}\\s*[\uFF1A:=]?`, "u").exec(normalized.slice(start));
    const end = nextMarker ? start + nextMarker.index : normalized.length;
    const raw = normalized.slice(start, end);
    return cleanupGeminiImagePrompt(raw);
  }
  function cleanupGeminiImagePrompt(value) {
    return value.replace(/^[\s,，。；;、]+/u, "").replace(/[\s,，；;、]+$/u, "").trim();
  }
  function extractGeminiGlobalConstraints(prompt) {
    return prompt.split(/(?<=[。！？!?])\s*/u).map((sentence) => sentence.trim()).filter((sentence) => /^每张图/u.test(sentence) || /^所有图片/u.test(sentence) || /^人物一致/u.test(sentence) || /^保持/u.test(sentence)).filter((sentence) => !/图\s*\d/u.test(sentence)).join("\n");
  }
  function findLatestJobConversationScope(turns, jobId) {
    for (let userIndex = turns.length - 1; userIndex >= 0; userIndex -= 1) {
      const user = turns[userIndex];
      if (user?.role !== "user" || !user.text.includes(`JOB_ID: ${jobId}`))
        continue;
      let assistantIndex = null;
      let nextUserIndex = null;
      for (let index = userIndex + 1; index < turns.length; index += 1) {
        const role = turns[index]?.role;
        if (role === "user") {
          nextUserIndex = index;
          break;
        }
        if (role === "assistant" && assistantIndex === null) {
          assistantIndex = index;
        }
      }
      return { userIndex, assistantIndex, nextUserIndex };
    }
    return null;
  }

  // src/gemini.ts
  function findGeminiSendControl(root = document) {
    return root.querySelector("gem-icon-button.send-button:not([aria-disabled='true'])") ?? root.querySelector("div[data-test-id='send-button-container']:not(.disabled) gem-icon-button.send-button") ?? root.querySelector("gem-icon-button.send-button") ?? root.querySelector("div[data-test-id='send-button-container']");
  }
  function isGeminiSendDisabled(control) {
    return control.classList.contains("disabled") || control.getAttribute("aria-disabled") === "true" || Boolean(control.querySelector('[aria-disabled="true"], [disabled]'));
  }

  // src/gptPreference.ts
  var GPT_IMAGE_PREFERENCE_TEST_ID = "image-paragen-multigen";
  var GPT_GENERATED_IMAGE_CARD_SELECTOR = "[id^='image-']";
  function findGptImagePreferenceComparisons(root) {
    return [...root.querySelectorAll(`[data-testid='${GPT_IMAGE_PREFERENCE_TEST_ID}']`)].map((container) => ({
      container,
      choices: findStructurallyAssociatedChoiceButtons(container)
    })).filter((comparison) => comparison.choices.length > 0);
  }
  function answerGptImagePreferenceComparisons(root, answeredComparisons) {
    let answered = false;
    for (const comparison of findGptImagePreferenceComparisons(root)) {
      if (answeredComparisons.has(comparison.container)) continue;
      answeredComparisons.add(comparison.container);
      comparison.choices[0]?.click();
      answered = true;
    }
    return answered;
  }
  function findStructurallyAssociatedChoiceButtons(container) {
    const choices = [];
    const seen = /* @__PURE__ */ new Set();
    for (const card of container.querySelectorAll(GPT_GENERATED_IMAGE_CARD_SELECTOR)) {
      const choice = findSiblingChoiceButton(card, container);
      if (!choice || seen.has(choice)) continue;
      seen.add(choice);
      choices.push(choice);
    }
    return choices;
  }
  function findSiblingChoiceButton(card, container) {
    for (let ancestor = card.parentElement; ancestor && ancestor !== container; ancestor = ancestor.parentElement) {
      const directButton = [...ancestor.children].find((child) => child.tagName === "BUTTON");
      if (directButton) return directButton;
    }
    return null;
  }

  // src/doubaoModel.ts
  function readDoubaoModel(metadata) {
    const value = metadata.doubaoModel;
    if (typeof value !== "string") return void 0;
    const trimmed = value.trim();
    return trimmed ? trimmed : void 0;
  }
  function normalize(value) {
    return value.replace(/\s+/g, " ").trim().toLowerCase();
  }
  function doubaoModelOptionName(optionText) {
    return optionText.split("\n")[0]?.trim() ?? "";
  }
  function doubaoModelTriggerName(triggerText) {
    return triggerText.replace(/\s+/g, " ").trim().replace(/^模型\s*/, "");
  }
  function matches(optionName, wanted) {
    const option = normalize(optionName);
    const target = normalize(wanted);
    if (!option || !target) return false;
    return option === target || option.endsWith(` ${target}`) || option.endsWith(target);
  }
  function isDoubaoModelSelected(triggerText, wanted) {
    return matches(doubaoModelTriggerName(triggerText), wanted);
  }
  function matchDoubaoModelOption(optionTexts, wanted) {
    const names = optionTexts.map(doubaoModelOptionName);
    const hits = names.map((name, index) => ({ name, index })).filter((item) => matches(item.name, wanted));
    if (hits.length === 1) return { index: hits[0].index };
    const available = names.filter(Boolean).join("\u3001") || "\uFF08\u672A\u8BFB\u5230\u4EFB\u4F55\u9009\u9879\uFF09";
    if (hits.length === 0) {
      return { errorMessage: `\u8C46\u5305\u6A21\u578B\u300C${wanted}\u300D\u672A\u5728\u4E0B\u62C9\u91CC\u627E\u5230\u3002\u53EF\u9009\uFF1A${available}` };
    }
    return {
      errorMessage: `\u8C46\u5305\u6A21\u578B\u300C${wanted}\u300D\u5339\u914D\u5230\u591A\u4E2A\u9009\u9879\uFF1A${hits.map((item) => item.name).join("\u3001")}\uFF0C\u8BF7\u5199\u5B8C\u6574\u540D\u79F0\u3002`
    };
  }

  // src/doubaoVideo.ts
  var DOUBAO_VIDEO_MIN_DURATION_SECONDS = 4;
  var DOUBAO_VIDEO_MAX_DURATION_SECONDS = 15;
  function readDoubaoVideoRatio(metadata) {
    const value = metadata.doubaoVideoRatio;
    if (typeof value !== "string") return void 0;
    const trimmed = value.trim();
    return trimmed ? trimmed : void 0;
  }
  function readDoubaoVideoDurationSeconds(metadata) {
    const value = metadata.doubaoVideoDuration;
    const seconds = typeof value === "number" ? value : typeof value === "string" ? Number(value.trim().replace(/s$/i, "")) : Number.NaN;
    return Number.isFinite(seconds) ? clampDurationSeconds(seconds) : void 0;
  }
  function clampDurationSeconds(seconds) {
    const rounded = Math.round(seconds);
    if (rounded < DOUBAO_VIDEO_MIN_DURATION_SECONDS) return DOUBAO_VIDEO_MIN_DURATION_SECONDS;
    if (rounded > DOUBAO_VIDEO_MAX_DURATION_SECONDS) return DOUBAO_VIDEO_MAX_DURATION_SECONDS;
    return rounded;
  }
  function doubaoVideoSliderValue(seconds) {
    return clampDurationSeconds(seconds) - DOUBAO_VIDEO_MIN_DURATION_SECONDS;
  }
  function matchDoubaoVideoRatioOption(optionTexts, wanted) {
    const names = optionTexts.map(normalizeRatio);
    const index = names.indexOf(normalizeRatio(wanted));
    if (index >= 0) return { index };
    const available = names.filter(Boolean).join("\u3001") || "\uFF08\u672A\u8BFB\u5230\u4EFB\u4F55\u6BD4\u4F8B\uFF09";
    return { errorMessage: `\u8C46\u5305\u89C6\u9891\u6BD4\u4F8B\u300C${wanted}\u300D\u672A\u5728\u9762\u677F\u91CC\u627E\u5230\u3002\u53EF\u9009\uFF1A${available}` };
  }
  function normalizeRatio(value) {
    return value.replace(/\s+/g, "").replace(/[：:]/g, ":").trim();
  }
  function parseDoubaoVideoParamsTrigger(triggerText) {
    const normalized = triggerText.replace(/\s+/g, " ").trim();
    const match = /^(.+?)\s*·\s*(\d+)\s*s$/.exec(normalized);
    if (!match) return null;
    return { ratio: match[1].trim(), seconds: Number(match[2]) };
  }
  function isDoubaoVideoConfirmLabel(label) {
    const normalized = label.replace(/\s+/g, "");
    return normalized.length <= 16 && /确[认定](继续)?生成/.test(normalized);
  }
  function isDoubaoVideoParamsApplied(triggerText, expected) {
    const parsed = parseDoubaoVideoParamsTrigger(triggerText);
    if (!parsed) return false;
    if (expected.ratio !== void 0 && normalizeRatio(parsed.ratio) !== normalizeRatio(expected.ratio)) return false;
    if (expected.seconds !== void 0 && parsed.seconds !== clampDurationSeconds(expected.seconds)) return false;
    return true;
  }

  // src/homeRedirectRecovery.ts
  var GPT_CONVERSATION_ID = /^(?:WEB:)?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;
  var GPT_UNAVAILABLE_CONTENT_PATTERN = /This\s+content\s+is\s+unavailable\s+or\s+could\s+not\s+be\s+found\.?/i;
  function gptConversationId(pathname) {
    const candidate = pathname.match(/^\/c\/([^/]+)$/)?.[1] ?? "";
    return GPT_CONVERSATION_ID.exec(candidate)?.[1] ?? null;
  }
  function isGptConversationPath(pathname) {
    return gptConversationId(pathname) !== null;
  }
  function normalizeGptConversationUrl(value) {
    if (!value) return null;
    try {
      const url = new URL(value);
      if (url.hostname !== "chatgpt.com") return null;
      const id = gptConversationId(url.pathname);
      return id ? `https://chatgpt.com/c/${id}` : null;
    } catch {
      return null;
    }
  }
  function shouldReloadCapturedConversation(input) {
    return normalizeGptConversationUrl(input.capturedUrl) !== null && !isGptConversationPath(input.currentPathname);
  }
  function hasGptUnavailableContentMessage(text) {
    return GPT_UNAVAILABLE_CONTENT_PATTERN.test(text);
  }

  // src/imageDownload.ts
  function isDoubaoDownloadControl(element) {
    const descriptor = [
      element.getAttribute("aria-label"),
      element.title,
      element.innerText,
      element.getAttribute("data-testid"),
      element.getAttribute("data-test-id"),
      element.getAttribute("data-action"),
      element.getAttribute("name"),
      element.className,
      element.outerHTML
    ].filter((value) => typeof value === "string" && value.length > 0).join(" ");
    return /download|save(?:[-_ ]?(?:image|picture))?|\u4e0b\u8f7d(?:\u539f\u56fe|\u56fe\u7247)?|\u4fdd\u5b58(?:\u539f\u56fe|\u56fe\u7247)?/i.test(descriptor);
  }
  var DOUBAO_DOWNLOAD_ICON_PATH_PREFIX = "M20.375 14.85";
  function hasDoubaoDownloadIcon(element) {
    return [...element.querySelectorAll("svg path")].some(
      (path) => (path.getAttribute("d") ?? "").trimStart().startsWith(DOUBAO_DOWNLOAD_ICON_PATH_PREFIX)
    );
  }
  var DOUBAO_VIDEO_DOWNLOAD_ICON_PATH_PREFIX = "M11.9922 1.99221";
  function hasDoubaoVideoDownloadIcon(element) {
    return [...element.querySelectorAll("svg path")].some(
      (path) => (path.getAttribute("d") ?? "").trimStart().startsWith(DOUBAO_VIDEO_DOWNLOAD_ICON_PATH_PREFIX)
    );
  }
  var DOUBAO_PREVIEW_MARKER_SELECTOR = "[aria-label^='marker-tool']";
  var DOUBAO_BRAND_BLUE = "rgb(0, 102, 255)";

  // src/inspect.ts
  var GENERATING_TEXT_PATTERN = /Thinking|Generating a more detailed image|hang tight|正在生成|生成中/i;
  var NOT_GENERATING_TEXT_PATTERN = /Stopped thinking/i;
  function hasGeneratingText(text) {
    return GENERATING_TEXT_PATTERN.test(text) && !NOT_GENERATING_TEXT_PATTERN.test(text);
  }
  function isGenerationStopControl(testId, label) {
    return testId === "stop-button" || /stop (generating|answering)|停止(生成|回答)/i.test(label);
  }

  // src/monitor.ts
  var GPT_IMAGE_RENDER_STALL_MIN_MS = 18e4;
  var GPT_IMAGE_STOP_CONFIRM_TIMEOUT_MS = 4e3;
  var EXPLICIT_GENERATION_ERROR_PATTERN = /Image generation failed|Something went wrong|There was a problem generating|Failed to generate|rate limit|too many requests|try again later|出了点问题|生成失败|请求过多|稍后再试/i;
  var GPT_IMAGE_GENERATION_FAILED_PATTERN = /Image generation failed/i;
  function hasExplicitGenerationError(text) {
    return EXPLICIT_GENERATION_ERROR_PATTERN.test(text);
  }
  function shouldRetryGptImageGenerationInPage(input) {
    return input.platform === "gpt" && input.mode === "image" && !input.retriedInPage && input.hasRetryButton && GPT_IMAGE_GENERATION_FAILED_PATTERN.test(input.errorText);
  }
  function shouldCompleteImageJob(input) {
    return input.mode === "image" && input.loadedImageCount >= input.expectedImageCount;
  }
  function shouldCompleteVideoJob(input) {
    return input.mode === "video" && input.loadedVideoCount >= 1;
  }
  var DOUBAO_VIDEO_WAIT_MIN_MS = 72e4;
  var DOUBAO_VIDEO_CONFIRM_MAX_CLICKS = 3;
  function shouldClickDoubaoVideoConfirm(input) {
    return input.platform === "doubao" && input.mode === "video" && input.hasConfirmButton && !input.isGenerating && input.loadedVideoCount === 0 && input.confirmClickCount < DOUBAO_VIDEO_CONFIRM_MAX_CLICKS;
  }
  function shouldFailCompletedDoubaoImageJob(input) {
    return input.platform === "doubao" && input.mode === "image" && input.assistantExists && Boolean(input.assistantText.trim()) && input.loadedImageCount === 0 && !input.isGenerating;
  }
  var DOUBAO_IMAGE_RENDER_GRACE_MS = 12e4;
  function shouldGiveUpOnMissingDoubaoImages(input) {
    return input.completedWithoutImagesAt > 0 && input.now - input.completedWithoutImagesAt >= DOUBAO_IMAGE_RENDER_GRACE_MS;
  }
  function shouldStopGptImageGeneration(input) {
    return input.platform === "gpt" && input.isGenerating && input.imageJobComplete;
  }
  function selectStuckGptImageStopRecovery(input) {
    if (input.platform !== "gpt" || !input.imageJobComplete || !input.isGenerating || !input.stopRequestedAt || input.now - input.stopRequestedAt < GPT_IMAGE_STOP_CONFIRM_TIMEOUT_MS) {
      return null;
    }
    return {
      errorMessage: "ChatGPT stop control remained loading for 4 seconds after a complete image was found; refreshing the conversation before collecting the image.",
      recoveryMode: "monitor_only"
    };
  }
  function shouldResubmitEmptyGptImage(input) {
    return input.platform === "gpt" && input.mode === "image" && input.sourceImageCount === 0 && input.assistantExists && !input.assistantText.trim() && input.loadedImageCount === 0 && !input.isGenerating && input.composerInteractive && input.hasOnlyResponseActionMenu;
  }
  function selectGptErrorRefresh(input) {
    if (input.platform !== "gpt" || input.refreshCount >= input.maxRefreshPerJob) return null;
    return {
      errorMessage: "ChatGPT reported an error; refreshing the submitted conversation before retrying.",
      recoveryMode: "retry_after_refresh"
    };
  }
  function selectMonitorStallRecovery(input) {
    if (input.platform === "gpt" && input.mode === "image" && input.isGenerating && input.idleMs >= GPT_IMAGE_RENDER_STALL_MIN_MS) {
      return {
        errorMessage: "ChatGPT image generation showed no visible progress for 3 minutes; refreshing the conversation and checking whether the submitted prompt remains.",
        recoveryMode: "resubmit_if_prompt_missing_after_refresh"
      };
    }
    if (!input.isGenerating && input.idleMs > effectiveStallTimeoutMs(input)) {
      return {
        errorMessage: "No visible progress before stall timeout.",
        recoveryMode: "monitor_only"
      };
    }
    return null;
  }
  function effectiveStallTimeoutMs(input) {
    if (input.platform === "doubao" && input.mode === "video") {
      return Math.max(input.stallTimeoutMs, DOUBAO_VIDEO_WAIT_MIN_MS);
    }
    return input.stallTimeoutMs;
  }

  // src/recovery.ts
  var GPT_EMPTY_ASSISTANT_CHECK_DELAY_MS = 15e3;
  function selectEmptyAssistantRecovery(input) {
    if (input.platform !== "gpt") return null;
    const isEmpty = !input.assistantExists || !input.assistantText.trim() && input.imageCount === 0;
    if (!isEmpty) return null;
    return "monitor_only";
  }
  function shouldCheckEmptyAssistantRecovery(platform, mode) {
    return platform === "gpt" && mode === "text";
  }
  async function waitForEmptyAssistantRecovery(options) {
    if (options.platform !== "gpt") return null;
    await delay(GPT_EMPTY_ASSISTANT_CHECK_DELAY_MS);
    if (options.signal.aborted) return null;
    const snapshot = await options.inspect();
    return selectEmptyAssistantRecovery({
      platform: options.platform,
      ...snapshot
    });
  }
  function shouldMonitorWithoutSubmit(input) {
    if (input.isGeminiMultiImage) return false;
    if (input.recoveryMode === "resubmit_after_refresh" || input.recoveryMode === "resubmit_if_prompt_missing_after_refresh") return false;
    if (input.recoveryMode) return true;
    return input.reloadOnly || input.hasExistingAssistant;
  }
  function selectPostRefreshPromptAction(input) {
    if (input.recoveryMode !== "resubmit_if_prompt_missing_after_refresh") return null;
    return input.hasJobUserTurn ? "monitor" : "resubmit";
  }
  function shouldRetryReloadWithoutJobTurn(input) {
    return input.reloadOnly && !input.hasJobUserTurn;
  }
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/readiness.ts
  var DEFAULT_TIMEOUT_MS = 1e4;
  var DEFAULT_POLL_INTERVAL_MS = 500;
  var DEFAULT_STABLE_POLLS = 3;
  async function waitForStableReadiness(options) {
    const now = options.now ?? Date.now;
    const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const pollIntervalMs = options.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS;
    const stablePolls = options.stablePolls ?? DEFAULT_STABLE_POLLS;
    const deadline = now() + timeoutMs;
    let consecutiveReadyPolls = 0;
    while (now() < deadline) {
      if (options.inspect()) {
        consecutiveReadyPolls += 1;
        if (consecutiveReadyPolls >= stablePolls) return "ready";
      } else {
        consecutiveReadyPolls = 0;
      }
      await options.sleep(Math.min(pollIntervalMs, Math.max(0, deadline - now())));
    }
    return "timeout";
  }

  // src/submit.ts
  var READY_POLL_INTERVAL_MS = 500;
  var READY_POLL_ATTEMPTS = 120;
  async function submitPromptWithFallback(options) {
    const { composer, sendButton, isSubmitted, sleep: sleep2 } = options;
    const readyButton = sendButton ? await waitForSendButtonReady(sendButton, options) : null;
    if (readyButton) {
      readyButton.click();
      if (await waitForSubmitted(isSubmitted, sleep2, 4, 250)) return true;
      if (await retryRequestSubmit(readyButton, options)) {
        if (await waitForSubmitted(isSubmitted, sleep2, 4, 250)) return true;
      }
    }
    composer.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
    await sleep2(100);
    return waitForSubmitted(isSubmitted, sleep2, 20, 500);
  }
  async function waitForSendButtonReady(sendButton, options) {
    let current = options.getSendButton?.() ?? sendButton;
    if (!isDisabled(current)) return current;
    await options.onWaitingForSubmitReady?.();
    for (let attempt = 0; attempt < READY_POLL_ATTEMPTS; attempt += 1) {
      await options.sleep(READY_POLL_INTERVAL_MS);
      current = options.getSendButton?.() ?? current;
      if (!isDisabled(current)) return current;
    }
    return null;
  }
  async function waitForSubmitted(isSubmitted, sleep2, attempts, delayMs) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      if (await isSubmitted()) return true;
      await sleep2(delayMs);
    }
    return false;
  }
  function isDisabled(button) {
    return button.disabled || button.getAttribute("aria-disabled") === "true";
  }
  var FORM_LOOKUP_RETRY_ATTEMPTS = 3;
  var FORM_LOOKUP_RETRY_DELAY_MS = 150;
  async function retryRequestSubmit(initialButton, options) {
    const { composer, getSendButton, sleep: sleep2 } = options;
    let button = initialButton;
    for (let attempt = 0; attempt < FORM_LOOKUP_RETRY_ATTEMPTS; attempt += 1) {
      if (attempt > 0) {
        await sleep2(FORM_LOOKUP_RETRY_DELAY_MS);
        button = getSendButton?.() ?? button;
      }
      const form = button.closest("form") ?? composer.closest("form");
      if (form?.isConnected && safeRequestSubmit(form, button)) return true;
    }
    return false;
  }
  function safeRequestSubmit(form, submitter) {
    try {
      if (form.contains(submitter)) {
        form.requestSubmit(submitter);
        return true;
      }
      form.requestSubmit();
      return true;
    } catch {
      return false;
    }
  }

  // src/content.ts
  var activeJob = null;
  var config = null;
  var monitorAbort = null;
  var INTERRUPTED_TEXT_PATTERN = /Connection interrupted|Waiting for the complete answer|连接中断|等待完整回答/i;
  var MONITOR_INTERVAL_MS = 5e3;
  var TEXT_DONE_STABLE_MS = 1e3;
  var IMAGE_DONE_STABLE_MS = 2e3;
  var VIDEO_DONE_STABLE_MS = 2e3;
  var GEMINI_SINGLE_IMAGE_DONE_STABLE_MS = 2e3;
  var EMPTY_GPT_IMAGE_RECOVERY_DELAY_MS = 1e4;
  var GEMINI_IMAGE_STALL_MIN_MS = 48e4;
  var answeredGptImagePreferenceComparisons = /* @__PURE__ */ new WeakSet();
  var RetryableJobError = class extends Error {
  };
  function isExtensionContextAlive() {
    return Boolean(chrome.runtime?.id);
  }
  function isExtensionContextInvalidated(error) {
    return /Extension context invalidated|message port closed/i.test(String(error));
  }
  window.addEventListener("unhandledrejection", (event) => {
    if (!isExtensionContextInvalidated(event.reason)) return;
    event.preventDefault();
    monitorAbort?.abort();
  });
  function platformLabel() {
    if (activeJob?.platform === "gemini") return "Gemini";
    if (activeJob?.platform === "doubao") return "\u8C46\u5305";
    return "ChatGPT";
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const typed = message;
    if (typed.type === "START_JOB") {
      const start = typed;
      void startJob(start.job, start.config, start.recoveryMode).then(() => sendResponse({ ok: true })).catch(async (error) => {
        await report(start.job.id, error instanceof RetryableJobError ? "failed_retryable" : "needs_manual", String(error));
        sendResponse({ ok: false, error: String(error) });
      });
      return true;
    }
    if (typed.type === "DEBUG_INSPECT") {
      void debugInspect(typed.jobId).then(sendResponse).catch((error) => {
        sendResponse({ ok: false, error: String(error) });
      });
      return true;
    }
    if (typed.type === "CHECK_GPT_EXISTING_CONVERSATION_REDIRECT") {
      const result = {
        hasUnavailableContent: hasGptUnavailableContentMessage(document.body?.innerText ?? "")
      };
      sendResponse(result);
      return false;
    }
    return false;
  });
  async function startJob(job, nextConfig, recoveryMode) {
    activeJob = job;
    config = nextConfig;
    monitorAbort?.abort();
    const controller = new AbortController();
    monitorAbort = controller;
    await traceJob(job.id, "content_start", {
      platform: job.platform,
      mode: job.mode,
      expectedImageCount: job.expectedImageCount,
      recoveryMode: recoveryMode ?? "initial",
      reloadOnly: isReloadOnly(job)
    });
    if (isReloadOnly(job)) {
      const hasJobUserTurn = await waitForReloadConversation(job.id);
      if (shouldRetryReloadWithoutJobTurn({ reloadOnly: true, hasJobUserTurn })) {
        await report(
          job.id,
          "failed_retryable",
          `Reload-only recovery could not find the submitted user turn for JOB_ID ${job.id}. The prompt may not have been submitted. Run auto-chat retry ${job.id}; do not use auto-chat reload for this failure.`
        );
        return;
      }
    }
    const postRefreshPromptAction = selectPostRefreshPromptAction({
      recoveryMode,
      hasJobUserTurn: recoveryMode === "resubmit_if_prompt_missing_after_refresh" ? await waitForReloadConversation(job.id) : false
    });
    if (postRefreshPromptAction === "monitor") {
      await traceJob(job.id, "post_refresh_prompt_found", { recoveryMode });
      await report(job.id, "waiting_generation");
      void monitorJob(job, nextConfig, controller.signal);
      return;
    }
    if (postRefreshPromptAction === "resubmit") {
      await traceJob(job.id, "post_refresh_prompt_missing", { recoveryMode });
    }
    const existing = findJobAssistant(job.id);
    const isGeminiMultiImage = job.platform === "gemini" && job.mode === "image" && job.expectedImageCount > 1;
    if (shouldMonitorWithoutSubmit({
      recoveryMode,
      reloadOnly: isReloadOnly(job),
      hasExistingAssistant: Boolean(existing),
      isGeminiMultiImage
    })) {
      await traceJob(job.id, "monitor_only_selected", {
        recoveryMode: recoveryMode ?? "existing_conversation",
        hasExistingAssistant: Boolean(existing)
      });
      if (recoveryMode || isReloadOnly(job)) {
        await report(job.id, "waiting_generation");
      }
      void monitorJob(job, nextConfig, controller.signal, recoveryMode === "retry_after_refresh");
      return;
    }
    if (job.platform === "gemini" && job.mode === "image") {
      await traceJob(job.id, "gemini_image_flow_selected", {
        recoveryMode: recoveryMode ?? "initial",
        startFromFreshChat: Boolean(recoveryMode) && Boolean(existing)
      });
      void runGeminiImageJob(job, nextConfig, controller.signal, Boolean(recoveryMode) && Boolean(existing));
      return;
    }
    await report(job.id, "waiting_chat_ready");
    await waitForComposer();
    await waitForConversationPageReady(job);
    if (job.platform === "gpt") {
      if (recoveryMode === "resubmit_after_refresh") {
        const state = await inspectJob(job.id, job.platform);
        if (!shouldResubmitEmptyGptImage({
          platform: job.platform,
          mode: job.mode,
          sourceImageCount: job.sourceImages.length,
          assistantExists: state.assistantExists,
          assistantText: state.assistantText,
          loadedImageCount: state.loadedImages.length,
          isGenerating: state.isGenerating,
          composerInteractive: isComposerReadyForNextPrompt(),
          hasOnlyResponseActionMenu: hasOnlyResponseActionMenu(job.id)
        })) {
          await report(job.id, "waiting_generation");
          void monitorJob(job, nextConfig, controller.signal).finally(() => controller.abort());
          return;
        }
      }
      await report(job.id, "uploading");
      await uploadSources(job);
      await report(job.id, "sending_prompt");
      await fillPromptAndSendGpt(
        job,
        recoveryMode === "resubmit_after_refresh" || postRefreshPromptAction === "resubmit"
      );
    } else if (job.platform === "doubao") {
      if (job.sourceImages.length > 0) {
        await report(job.id, "uploading");
        await uploadSources(job);
        await waitForDoubaoUploadReady(job.id);
      }
      await report(job.id, "sending_prompt");
      await fillPromptAndSendDoubao(job);
    } else {
      await fillPromptPasteSourcesAndSendGemini(job, job.prompt);
    }
    await traceJob(job.id, "prompt_submitted", {
      platform: job.platform,
      mode: job.mode,
      recoveryMode: recoveryMode ?? "initial"
    });
    await report(job.id, "waiting_generation");
    void monitorJob(job, nextConfig, controller.signal).finally(() => controller.abort());
    if (shouldCheckEmptyAssistantRecovery(job.platform, job.mode)) {
      void recoverEmptyGptAssistant(job, controller);
    }
  }
  async function recoverEmptyGptAssistant(job, controller) {
    try {
      const recoveryMode = await waitForEmptyAssistantRecovery({
        platform: job.platform,
        signal: controller.signal,
        inspect: async () => {
          const state = await inspectJob(job.id, job.platform);
          return {
            assistantExists: state.assistantExists,
            assistantText: state.assistantText,
            imageCount: state.loadedImages.length
          };
        }
      });
      if (!recoveryMode || controller.signal.aborted) return;
      controller.abort();
      await sendProgress({
        type: "JOB_PROGRESS",
        jobId: job.id,
        status: "stalled",
        recoveryMode,
        errorMessage: "GPT assistant remained empty 15 seconds after prompt submission."
      });
    } catch (error) {
      if (!controller.signal.aborted) await report(job.id, "failed_retryable", String(error));
    }
  }
  async function runGeminiImageJob(job, appConfig, signal, startFromFreshChat = false) {
    const images = [];
    const total = Math.max(1, job.expectedImageCount);
    try {
      for (let outputIndex = 1; outputIndex <= total; outputIndex += 1) {
        if (signal.aborted) return;
        await traceJob(job.id, "gemini_image_turn_started", { outputIndex, total });
        if (outputIndex > 1 || startFromFreshChat) await startGeminiNewChat(appConfig);
        const prompt = total > 1 ? buildGeminiOutputPrompt(job.prompt, outputIndex, geminiPrompts(job)) : job.prompt;
        await report(job.id, "waiting_chat_ready");
        await waitForComposer();
        await waitForConversationPageReady(job, outputIndex === 1 && !startFromFreshChat && hasRecordedConversation(job));
        await fillPromptPasteSourcesAndSendGemini(job, prompt);
        await report(job.id, "waiting_generation");
        const image = await waitForGeminiSingleImage(job, appConfig, signal);
        images.push({ ...image, index: outputIndex - 1 });
        await traceJob(job.id, "gemini_image_turn_collected", { outputIndex, total });
        await sendProgress({ type: "JOB_PROGRESS", jobId: job.id, status: "maybe_done", images: [...images] });
      }
      await sendProgress({
        type: "JOB_PROGRESS",
        jobId: job.id,
        status: "done",
        images
      });
    } catch (error) {
      await traceJob(job.id, "gemini_image_flow_failed", { message: String(error) });
      await report(job.id, "failed_retryable", String(error));
    }
  }
  function geminiPrompts(job) {
    const value = job.metadata.geminiPrompts;
    if (!Array.isArray(value) || !value.every((item) => typeof item === "string")) return void 0;
    return value;
  }
  function isReloadOnly(job) {
    return job.metadata.autoChatReloadOnly === true;
  }
  async function waitForReloadConversation(jobId) {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const turn = findJobUserTurn(jobId);
      if (turn) {
        turn.scrollIntoView({ block: "center" });
        await sleep(500);
        return true;
      }
      window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "auto" });
      await sleep(500);
    }
    return false;
  }
  async function waitForGeminiSingleImage(job, appConfig, signal) {
    const startedAt = Date.now();
    let lastSignature = "";
    let lastChangedAt = Date.now();
    let maybeDoneAt = 0;
    let retriedInPage = false;
    while (!signal.aborted) {
      const state = await inspectJob(job.id, "gemini");
      if (state.signature !== lastSignature) {
        lastSignature = state.signature;
        lastChangedAt = Date.now();
        maybeDoneAt = 0;
      }
      if (state.hasError) {
        if (!retriedInPage) {
          retriedInPage = true;
          const retryButton = findJobScopeRetryButton(job.id, "gemini");
          if (retryButton) {
            retryButton.click();
            lastChangedAt = Date.now();
            maybeDoneAt = 0;
            await sleep(MONITOR_INTERVAL_MS);
            continue;
          }
        }
        throw new Error(state.errorText || "Gemini returned an error.");
      }
      if (state.isInterrupted) throw new Error(state.interruptedText || "Gemini response was interrupted.");
      if (Date.now() - startedAt > appConfig.hardTimeoutMs) throw new Error("Job exceeded hard timeout.");
      const stallTimeoutMs = Math.max(appConfig.stallTimeoutMs, GEMINI_IMAGE_STALL_MIN_MS);
      if (!state.isGenerating && Date.now() - lastChangedAt > stallTimeoutMs) {
        throw new Error("No visible progress before stall timeout.");
      }
      if (state.loadedImages.length >= 1 && !state.isGenerating) {
        if (!maybeDoneAt) {
          maybeDoneAt = Date.now();
          await sendProgress({ type: "JOB_PROGRESS", jobId: job.id, status: "maybe_done", signature: state.signature });
        }
        if (Date.now() - maybeDoneAt > GEMINI_SINGLE_IMAGE_DONE_STABLE_MS) {
          const [image] = await collectImages(state.loadedImages.slice(0, 1));
          if (!image) throw new Error("Gemini image was visible but could not be collected.");
          return image;
        }
      }
      await sleep(MONITOR_INTERVAL_MS);
    }
    throw new Error("Gemini job was aborted.");
  }
  async function startGeminiNewChat(appConfig) {
    const newChat = findVisibleElement('a[aria-label="New chat"], a[data-test-id="side-nav-sparkle-button"], a[href="/app"]');
    await setExpectingNavigation(true);
    try {
      if (newChat) {
        newChat.click();
      } else if (!location.href.startsWith(appConfig.geminiUrl)) {
        location.href = appConfig.geminiUrl;
      } else {
        history.pushState(null, "", "/app");
        window.dispatchEvent(new PopStateEvent("popstate"));
      }
      await sleep(1500);
      await waitForComposer();
    } finally {
      await setExpectingNavigation(false);
    }
  }
  async function monitorJob(job, appConfig, signal, retryAfterRefresh = false) {
    const startedAt = Date.now();
    let lastSignature = "";
    let lastChangedAt = Date.now();
    let maybeDoneAt = 0;
    let retriedInPage = false;
    let gptStopRequestedAt = 0;
    let capturedGptImages = null;
    let doubaoNoImageDoneAt = 0;
    let doubaoVideoConfirmClicks = 0;
    let tracedDoubaoVideoControls = false;
    let resubmittedEmptyGptImage = hasResubmittedEmptyGptImage(job.id);
    let lastTraceSignature = "";
    await traceJob(job.id, "monitor_started", {
      platform: job.platform,
      mode: job.mode,
      retryAfterRefresh,
      stallTimeoutMs: appConfig.stallTimeoutMs,
      hardTimeoutMs: appConfig.hardTimeoutMs
    });
    try {
      while (!signal.aborted) {
        if (!isExtensionContextAlive()) return;
        if (job.platform === "gpt" && dismissRateLimitModal()) {
          await traceJob(job.id, "rate_limit_modal_detected", { platform: job.platform });
          await report(job.id, "rate_limited");
          return;
        }
        if (job.platform === "gpt" && job.mode === "image" && answerGptImagePreferences(job.id)) {
          await traceJob(job.id, "gpt_image_preference_answered", { platform: job.platform });
          lastChangedAt = Date.now();
          maybeDoneAt = 0;
          await sleep(1e3);
          continue;
        }
        const state = await inspectJob(job.id, job.platform);
        if (state.signature !== lastSignature) {
          lastSignature = state.signature;
          lastChangedAt = Date.now();
          maybeDoneAt = 0;
          doubaoNoImageDoneAt = 0;
        }
        if (state.signature !== lastTraceSignature) {
          lastTraceSignature = state.signature;
          await traceJob(job.id, "monitor_snapshot", monitorSnapshot(job, state));
        }
        const visibleEnoughImages = shouldCompleteImageJob({
          mode: job.mode,
          loadedImageCount: state.loadedImages.length,
          expectedImageCount: job.expectedImageCount
        });
        if (visibleEnoughImages && !capturedGptImages && job.platform === "gpt" && state.isGenerating) {
          capturedGptImages = await collectImages(state.loadedImages.slice(0, job.expectedImageCount));
          await traceJob(job.id, "gpt_image_captured_before_stop", { imageCount: capturedGptImages.length });
        }
        const enoughImages = visibleEnoughImages || capturedGptImages !== null;
        if (enoughImages) {
          await traceJob(job.id, "expected_images_detected", monitorSnapshot(job, state));
          if (!gptStopRequestedAt && shouldStopGptImageGeneration({
            platform: job.platform,
            isGenerating: state.isGenerating,
            imageJobComplete: enoughImages
          })) {
            stopActiveGptGeneration();
            gptStopRequestedAt = Date.now();
            await traceJob(job.id, "gpt_stop_requested_after_image", monitorSnapshot(job, state));
            maybeDoneAt = 0;
            await sleep(500);
            continue;
          }
          const stuckStopRecovery = selectStuckGptImageStopRecovery({
            platform: job.platform,
            imageJobComplete: enoughImages,
            isGenerating: state.isGenerating,
            stopRequestedAt: gptStopRequestedAt,
            now: Date.now()
          });
          if (stuckStopRecovery) {
            await traceJob(job.id, "monitor_recovery_selected", {
              ...monitorSnapshot(job, state),
              reason: stuckStopRecovery.errorMessage,
              recoveryMode: stuckStopRecovery.recoveryMode
            });
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "stalled",
              recoveryMode: stuckStopRecovery.recoveryMode,
              errorMessage: stuckStopRecovery.errorMessage
            });
            return;
          }
          if (gptStopRequestedAt && state.isGenerating) {
            await sleep(500);
            continue;
          }
          if (!maybeDoneAt) {
            maybeDoneAt = Date.now();
            await sendProgress({ type: "JOB_PROGRESS", jobId: job.id, status: "maybe_done", signature: state.signature });
          }
          if (Date.now() - maybeDoneAt > IMAGE_DONE_STABLE_MS) {
            await traceJob(job.id, "image_collection_started", monitorSnapshot(job, state));
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "done",
              signature: state.signature,
              images: capturedGptImages ?? await collectImages(state.loadedImages.slice(0, job.expectedImageCount))
            });
            return;
          }
          await sleep(MONITOR_INTERVAL_MS);
          continue;
        }
        if (job.platform === "doubao" && job.mode === "video") {
          const confirmButton = findDoubaoVideoConfirmButton(job.id);
          if (!confirmButton && !tracedDoubaoVideoControls && state.assistantExists) {
            tracedDoubaoVideoControls = true;
            await traceJob(job.id, "doubao_video_scope_controls", { controls: describeJobScopeControls(job.id) });
          }
          if (shouldClickDoubaoVideoConfirm({
            platform: job.platform,
            mode: job.mode,
            hasConfirmButton: Boolean(confirmButton),
            loadedVideoCount: state.loadedVideos.length,
            isGenerating: state.isGenerating,
            confirmClickCount: doubaoVideoConfirmClicks
          })) {
            doubaoVideoConfirmClicks += 1;
            clickDoubaoControl(confirmButton);
            await traceJob(job.id, "doubao_video_confirm_clicked", {
              ...monitorSnapshot(job, state),
              confirmClickCount: doubaoVideoConfirmClicks
            });
            lastChangedAt = Date.now();
            maybeDoneAt = 0;
            await sleep(MONITOR_INTERVAL_MS);
            continue;
          }
        }
        if (shouldCompleteVideoJob({ mode: job.mode, loadedVideoCount: state.loadedVideos.length })) {
          if (!maybeDoneAt) {
            maybeDoneAt = Date.now();
            await sendProgress({ type: "JOB_PROGRESS", jobId: job.id, status: "maybe_done", signature: state.signature });
          }
          if (Date.now() - maybeDoneAt > VIDEO_DONE_STABLE_MS) {
            await traceJob(job.id, "video_collection_started", monitorSnapshot(job, state));
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "done",
              signature: state.signature,
              videos: await collectVideos(state.loadedVideos.slice(0, 1))
            });
            return;
          }
          await sleep(MONITOR_INTERVAL_MS);
          continue;
        }
        if (state.isGenerating) {
          const renderStallRecovery = selectMonitorStallRecovery({
            platform: job.platform,
            mode: job.mode,
            isGenerating: state.isGenerating,
            idleMs: Date.now() - lastChangedAt,
            stallTimeoutMs: appConfig.stallTimeoutMs
          });
          if (renderStallRecovery) {
            await traceJob(job.id, "monitor_recovery_selected", {
              ...monitorSnapshot(job, state),
              reason: renderStallRecovery.errorMessage,
              recoveryMode: renderStallRecovery.recoveryMode
            });
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "stalled",
              recoveryMode: renderStallRecovery.recoveryMode,
              errorMessage: renderStallRecovery.errorMessage
            });
            return;
          }
          await sleep(MONITOR_INTERVAL_MS);
          continue;
        }
        if (state.hasError) {
          await traceJob(job.id, "explicit_error_detected", monitorSnapshot(job, state));
          const retryButton = job.platform === "gpt" && job.mode === "image" ? findJobScopeRetryButton(job.id, job.platform) : null;
          if (shouldRetryGptImageGenerationInPage({
            platform: job.platform,
            mode: job.mode,
            errorText: state.errorText,
            retriedInPage,
            hasRetryButton: Boolean(retryButton)
          })) {
            retriedInPage = true;
            await traceJob(job.id, "gpt_retry_button_clicked", {
              errorText: state.errorText.slice(0, 200)
            });
            retryButton.click();
            lastChangedAt = Date.now();
            maybeDoneAt = 0;
            await sleep(MONITOR_INTERVAL_MS);
            continue;
          }
          const errorRecovery = retryAfterRefresh ? null : selectGptErrorRefresh({
            platform: job.platform,
            refreshCount: job.refreshCount,
            maxRefreshPerJob: appConfig.maxRefreshPerJob
          });
          if (errorRecovery) {
            await traceJob(job.id, "monitor_recovery_selected", {
              ...monitorSnapshot(job, state),
              reason: errorRecovery.errorMessage,
              recoveryMode: errorRecovery.recoveryMode
            });
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "stalled",
              recoveryMode: errorRecovery.recoveryMode,
              errorMessage: errorRecovery.errorMessage
            });
            return;
          }
          if ((job.platform === "gpt" || job.platform === "gemini") && !retriedInPage) {
            retriedInPage = true;
            const retryButton2 = findJobScopeRetryButton(job.id, job.platform);
            if (retryButton2) {
              retryButton2.click();
              lastChangedAt = Date.now();
              maybeDoneAt = 0;
              await sleep(MONITOR_INTERVAL_MS);
              continue;
            }
          }
          await report(job.id, "failed_retryable", state.errorText);
          return;
        }
        if (state.isInterrupted) {
          await traceJob(job.id, "interrupted_response_detected", monitorSnapshot(job, state));
          await report(job.id, "stalled", state.interruptedText || "Connection interrupted while waiting for the complete answer.");
          return;
        }
        if (shouldFailCompletedDoubaoImageJob({
          platform: job.platform,
          mode: job.mode,
          assistantExists: state.assistantExists,
          assistantText: state.assistantText,
          loadedImageCount: state.loadedImages.length,
          isGenerating: state.isGenerating
        })) {
          if (!doubaoNoImageDoneAt) {
            doubaoNoImageDoneAt = Date.now();
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "maybe_done",
              signature: state.signature
            });
          }
          if (shouldGiveUpOnMissingDoubaoImages({ completedWithoutImagesAt: doubaoNoImageDoneAt, now: Date.now() })) {
            const errorMessage = "\u8C46\u5305\u4F1A\u8BDD\u5DF2\u7ED3\u675F\uFF0C\u4F46\u672A\u68C0\u6D4B\u5230\u751F\u6210\u56FE\u7247\u3002";
            await traceJob(job.id, "doubao_image_missing_after_completed_response", {
              ...monitorSnapshot(job, state),
              waitedMs: Date.now() - doubaoNoImageDoneAt,
              reason: errorMessage
            });
            await report(job.id, "failed_retryable", errorMessage);
            return;
          }
          await sleep(MONITOR_INTERVAL_MS);
          continue;
        }
        if (!resubmittedEmptyGptImage && Date.now() - lastChangedAt >= EMPTY_GPT_IMAGE_RECOVERY_DELAY_MS && shouldResubmitEmptyGptImage({
          platform: job.platform,
          mode: job.mode,
          sourceImageCount: job.sourceImages.length,
          assistantExists: state.assistantExists,
          assistantText: state.assistantText,
          loadedImageCount: state.loadedImages.length,
          isGenerating: state.isGenerating,
          composerInteractive: isComposerReadyForNextPrompt(),
          hasOnlyResponseActionMenu: hasOnlyResponseActionMenu(job.id)
        })) {
          resubmittedEmptyGptImage = true;
          markEmptyGptImageResubmitted(job.id);
          await traceJob(job.id, "monitor_recovery_selected", {
            ...monitorSnapshot(job, state),
            reason: "GPT returned an empty image response.",
            recoveryMode: "resubmit_after_refresh"
          });
          await sendProgress({
            type: "JOB_PROGRESS",
            jobId: job.id,
            status: "stalled",
            recoveryMode: "resubmit_after_refresh",
            errorMessage: "GPT returned an empty image response; refreshing the conversation before one resubmission."
          });
          return;
        }
        if (Date.now() - startedAt > appConfig.hardTimeoutMs) {
          await traceJob(job.id, "hard_timeout", monitorSnapshot(job, state));
          await report(job.id, "needs_manual", "Job exceeded hard timeout.");
          return;
        }
        const stallRecovery = selectMonitorStallRecovery({
          platform: job.platform,
          mode: job.mode,
          isGenerating: state.isGenerating,
          idleMs: Date.now() - lastChangedAt,
          stallTimeoutMs: appConfig.stallTimeoutMs
        });
        if (stallRecovery) {
          await traceJob(job.id, "monitor_recovery_selected", {
            ...monitorSnapshot(job, state),
            reason: stallRecovery.errorMessage,
            recoveryMode: stallRecovery.recoveryMode
          });
          await sendProgress({
            type: "JOB_PROGRESS",
            jobId: job.id,
            status: "stalled",
            recoveryMode: stallRecovery.recoveryMode,
            errorMessage: stallRecovery.errorMessage
          });
          return;
        }
        if (job.mode === "text" && state.assistantText.trim() && !state.isGenerating) {
          if (!maybeDoneAt) {
            maybeDoneAt = Date.now();
            await sendProgress({ type: "JOB_PROGRESS", jobId: job.id, status: "maybe_done", signature: state.signature });
          }
          if (Date.now() - maybeDoneAt > TEXT_DONE_STABLE_MS) {
            await sendProgress({
              type: "JOB_PROGRESS",
              jobId: job.id,
              status: "done",
              signature: state.signature,
              text: await collectTextResponse(job.id, state.assistantText)
            });
            return;
          }
        }
        await sleep(MONITOR_INTERVAL_MS);
      }
    } catch (error) {
      await traceJob(job.id, "monitor_failed", { message: String(error) });
      await report(job.id, "failed_retryable", String(error));
    }
  }
  function answerGptImagePreferences(jobId) {
    const assistant = findJobAssistant(jobId);
    if (!assistant) return false;
    return answerGptImagePreferenceComparisons(assistant, answeredGptImagePreferenceComparisons);
  }
  async function inspectJob(jobId, platform) {
    const assistant = findJobAssistant(jobId);
    const scopedImages = findJobScopedImages(jobId);
    const pageImages = findLoadedImages(document);
    const loadedVideos = platform === "doubao" ? findJobScopedVideoCards(jobId) : [];
    if (!assistant) {
      const text2 = document.body.innerText;
      const jobText2 = findJobScopeText(jobId);
      const hasError2 = hasExplicitGenerationError(jobText2);
      const isInterrupted2 = INTERRUPTED_TEXT_PATTERN.test(jobText2);
      return {
        assistantExists: false,
        hasError: hasError2,
        errorText: hasError2 ? jobText2.slice(0, 500) : "",
        isInterrupted: isInterrupted2,
        interruptedText: isInterrupted2 ? jobText2.slice(0, 500) : "",
        isGenerating: hasGeneratingText(text2) || hasActiveGenerationControl(),
        assistantText: "",
        loadedImages: scopedImages,
        scopedImages,
        pageImages,
        loadedVideos,
        signature: `no-assistant:${text2.length}:${scopedImages.length}:${pageImages.length}:${loadedVideos.length}`
      };
    }
    const text = assistant.innerText || "";
    const jobText = findJobScopeText(jobId);
    const hasError = hasExplicitGenerationError(`${text}
${jobText}`);
    const isInterrupted = INTERRUPTED_TEXT_PATTERN.test(`${text}
${jobText}`);
    const isGenerating = hasGeneratingText(text) || Boolean(assistant.querySelector('[aria-busy="true"], [data-testid*="loading"], .animate-pulse, [class*="dot-flashing"], [class*="loading-container"]')) || Boolean(assistant.querySelector('[data-streaming="true"]')) || hasActiveGenerationControl();
    const assistantImages = findGeneratedImagesInOrder(assistant).filter((image) => !isNonFirstDualResponseChoice(image));
    const loadedImages = uniqueImages([...assistantImages, ...scopedImages]);
    return {
      assistantExists: true,
      hasError,
      errorText: hasError ? text.slice(0, 500) : "",
      isInterrupted,
      interruptedText: isInterrupted ? jobText.slice(0, 500) : "",
      isGenerating,
      assistantText: extractAssistantText(assistant),
      loadedImages,
      scopedImages,
      pageImages,
      loadedVideos,
      signature: `${text.length}:${loadedImages.length}:${scopedImages.length}:${pageImages.length}:${loadedVideos.length}:${isGenerating}:${assistant.querySelectorAll("button,a").length}`
    };
  }
  async function debugInspect(jobId) {
    const resolvedJobId = jobId ?? activeJob?.id ?? findLatestJobId();
    const pageJobId = findLatestJobId();
    if (!resolvedJobId) {
      return {
        ok: true,
        jobId: null,
        pageJobId,
        url: location.href,
        hasJobAssistant: false,
        hasError: false,
        isInterrupted: false,
        isGenerating: hasGeneratingText(document.body.innerText),
        loadedImages: findLoadedImages(document).length,
        scopedImages: 0,
        pageImages: findLoadedImages(document).length,
        loadedVideos: 0,
        expectedImages: activeJob?.expectedImageCount ?? null,
        signature: `no-job:${document.body.innerText.length}`
      };
    }
    const state = await inspectJob(resolvedJobId, activeJob?.platform);
    return {
      ok: true,
      jobId: resolvedJobId,
      pageJobId,
      url: location.href,
      hasJobAssistant: state.assistantExists,
      hasError: state.hasError,
      isInterrupted: state.isInterrupted,
      isGenerating: state.isGenerating,
      loadedImages: state.loadedImages.length,
      scopedImages: state.scopedImages.length,
      pageImages: state.pageImages.length,
      loadedVideos: state.loadedVideos.length,
      expectedImages: activeJob?.id === resolvedJobId ? activeJob.expectedImageCount : null,
      signature: state.signature,
      errorText: state.errorText
    };
  }
  function findLatestJobId() {
    const matches2 = [...document.querySelectorAll("[data-message-author-role='user'], section[data-turn='user'], user-query, [data-message-id]")].map((node) => (node.innerText || "").match(/JOB_ID:\s*([^\s]+)/)?.[1]).filter((value) => Boolean(value));
    return matches2.at(-1) ?? null;
  }
  function findJobAssistant(jobId) {
    return findJobConversationScope(jobId)?.assistant ?? null;
  }
  function countJobUserTurns(jobId) {
    return findConversationTurns().filter(isUserTurn).filter((turn) => (turn.innerText || "").includes(`JOB_ID: ${jobId}`)).length;
  }
  function emptyGptImageResubmitKey(jobId) {
    return `auto-chat:empty-gpt-image-resubmit:${jobId}`;
  }
  function hasResubmittedEmptyGptImage(jobId) {
    return sessionStorage.getItem(emptyGptImageResubmitKey(jobId)) === "1";
  }
  function markEmptyGptImageResubmitted(jobId) {
    sessionStorage.setItem(emptyGptImageResubmitKey(jobId), "1");
  }
  function findJobScopedImages(jobId) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return [];
    return findLoadedImages(document).filter(
      (img) => !scope.user.contains(img) && isAfter(img, scope.user) && (!scope.nextUser || isBefore(img, scope.nextUser))
    );
  }
  function findJobScopeText(jobId) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return "";
    const turns = findConversationTurns();
    const scopedTurns = turns.filter(
      (node) => (node === scope.user || isAfter(node, scope.user)) && (!scope.nextUser || node === scope.nextUser || isBefore(node, scope.nextUser)) && node !== scope.nextUser
    );
    return scopedTurns.map((node) => node.innerText || "").join("\n");
  }
  function dismissRateLimitModal() {
    const modal = document.getElementById("modal-conversation-history-rate-limit");
    if (!modal || !isVisible(modal)) return false;
    const dismissButton = [...modal.querySelectorAll("button")].find((button) => isVisible(button) && /got it/i.test(button.innerText));
    dismissButton?.click();
    return true;
  }
  function findJobScopeRetryButton(jobId, platform) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return null;
    const buttons = [...document.querySelectorAll("button,[role='button'],gem-icon-button")].filter(
      (button) => isAfter(button, scope.user) && (!scope.nextUser || isBefore(button, scope.nextUser))
    );
    const retryPattern = platform === "gemini" ? /retry|try again|regenerate|redo|重试|重新生成/i : /retry|try again|regenerate|重试|重新生成/i;
    const byLabel = buttons.find((button) => {
      const label = `${button.innerText ?? ""} ${button.getAttribute("aria-label") ?? ""} ${button.title ?? ""}`;
      return isVisible(button) && retryPattern.test(label);
    });
    if (byLabel) return byLabel;
    const actionsGroup = buttons.find((button) => button.getAttribute("aria-label") === "Share")?.closest('[aria-label="Response actions"]');
    if (!actionsGroup) return null;
    const groupButtons = [...actionsGroup.querySelectorAll("button")].filter(isVisible);
    const shareIndex = groupButtons.findIndex((button) => button.getAttribute("aria-label") === "Share");
    return shareIndex >= 0 ? groupButtons[shareIndex + 1] ?? null : null;
  }
  function findDoubaoVideoConfirmButton(jobId) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return null;
    const matches2 = [...document.querySelectorAll("button,[role='button'],a,div,span")].filter(
      (element) => isAfter(element, scope.user) && (!scope.nextUser || isBefore(element, scope.nextUser)) && isPresentInLayout(element) && isLikelyClickable(element) && isDoubaoVideoConfirmLabel(elementLabel(element))
    );
    const innermost = matches2.filter((element) => !matches2.some((other) => other !== element && element.contains(other)));
    const target = innermost[innermost.length - 1] ?? null;
    return target?.closest("button,[role='button']") ?? target;
  }
  function isLikelyClickable(element) {
    if (element.tagName === "BUTTON" || element.tagName === "A") return true;
    if (element.getAttribute("role") === "button") return true;
    return getComputedStyle(element).cursor === "pointer";
  }
  function elementLabel(element) {
    return `${element.innerText ?? ""} ${element.getAttribute("aria-label") ?? ""}`.replace(/\s+/g, " ").trim();
  }
  function describeJobScopeControls(jobId) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return [];
    const candidates = scope.assistant ? [...scope.assistant.querySelectorAll("*")] : [...document.querySelectorAll("button,[role='button'],a")].filter((element) => isAfter(element, scope.user) && (!scope.nextUser || isBefore(element, scope.nextUser)));
    const clickable = candidates.filter((element) => isPresentInLayout(element) && isLikelyClickable(element));
    return clickable.filter((element) => !clickable.some((other) => other !== element && element.contains(other))).slice(0, 24).map((element) => `${element.tagName.toLowerCase()}:${elementLabel(element).slice(0, 40)}`);
  }
  function findJobConversationScope(jobId) {
    const turns = findConversationTurns();
    const scope = findLatestJobConversationScope(turns.map((turn) => ({
      role: conversationTurnRole(turn),
      text: turn.innerText || ""
    })), jobId);
    if (!scope) return null;
    return {
      user: turns[scope.userIndex],
      assistant: scope.assistantIndex === null ? null : turns[scope.assistantIndex],
      nextUser: scope.nextUserIndex === null ? null : turns[scope.nextUserIndex]
    };
  }
  function conversationTurnRole(node) {
    if (isUserTurn(node)) return "user";
    if (isAssistantTurn(node)) return "assistant";
    return "other";
  }
  function findLoadedImages(root) {
    return uniqueImages([...findGeneratedImagesInOrder(root), ...findGeneratedImageElements(root)]).filter((image) => !isNonFirstDualResponseChoice(image));
  }
  function findGeneratedImagesInOrder(root) {
    const cards = [...root.querySelectorAll(".group\\/imagegen-image, [id^='image-'], generated-image, single-image")];
    const images = cards.map((card) => findGeneratedImageElements(card)[0]).filter((image) => Boolean(image));
    return uniqueImages(images);
  }
  function isNonFirstDualResponseChoice(image) {
    const dualResponse = image.closest("dual-model-response");
    if (!dualResponse) return false;
    const panel = image.closest("response-selection-panel");
    if (!panel) return false;
    const panels = dualResponse.querySelectorAll("response-selection-panel");
    return panels[0] !== panel;
  }
  function findGeneratedImageElements(root) {
    return [...root.querySelectorAll("img")].filter((img) => {
      const src = img.currentSrc || img.src;
      const attrWidth = Number(img.getAttribute("width") ?? 0);
      const attrHeight = Number(img.getAttribute("height") ?? 0);
      const width = img.naturalWidth || attrWidth || img.width;
      const height = img.naturalHeight || attrHeight || img.height;
      const largeEnough = width > 100 && height > 100;
      const hasEstuarySource = /\/backend-api\/estuary\/content/i.test(src);
      const hasGeminiBlob = /^blob:https:\/\/gemini\.google\.com\//i.test(src);
      const hasDoubaoGenSource = /imagex-sign\.byteimg\.com\/.*rc_gen_image/i.test(src);
      const hasGeneratedAlt = /Generated image/i.test(img.alt);
      const hasGeminiGeneratedAlt = /AI generated/i.test(img.alt);
      const isDecorative = /gstatic\.com\/lamda\/images\/gemini|googleusercontent\.com\/a\//i.test(src);
      const inGeneratedContainer = Boolean(img.closest(".group\\/imagegen-image, [id^='image-'], generated-image, single-image"));
      return Boolean(src) && !isDecorative && (hasEstuarySource || hasGeminiBlob || hasDoubaoGenSource || inGeneratedContainer || (hasGeneratedAlt || hasGeminiGeneratedAlt) && largeEnough);
    });
  }
  function monitorSnapshot(job, state) {
    return {
      platform: job.platform,
      mode: job.mode,
      expectedImageCount: job.expectedImageCount,
      assistantExists: state.assistantExists,
      loadedImageCount: state.loadedImages.length,
      scopedImageCount: state.scopedImages.length,
      pageImageCount: state.pageImages.length,
      loadedVideoCount: state.loadedVideos.length,
      isGenerating: state.isGenerating,
      hasError: state.hasError,
      errorText: state.errorText || null,
      isInterrupted: state.isInterrupted,
      interruptedText: state.interruptedText || null,
      assistantTextLength: state.assistantText.length,
      signature: state.signature
    };
  }
  function extractAssistantText(assistant) {
    const content = assistant.cloneNode(true);
    content.querySelectorAll('[aria-label="Response actions"], h4.sr-only, button, [role="button"]').forEach((control) => control.remove());
    const message = content.querySelector("[data-message-author-role='assistant']");
    const geminiMessage = content.querySelector("message-content .markdown, .model-response-text .markdown");
    const markdown = message?.querySelector(".markdown") ?? geminiMessage;
    return ((markdown ? serializeRichText(markdown) : "") || message?.innerText || content.innerText || "").trim();
  }
  function serializeRichText(root) {
    return [...root.childNodes].map((node) => serializeBlock(node)).filter(Boolean).join("\n\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function serializeBlock(node, listIndex) {
    if (node.nodeType === Node.TEXT_NODE) return normalizeInline(node.textContent ?? "");
    if (!(node instanceof HTMLElement)) return "";
    const tag = node.tagName.toLowerCase();
    if (tag === "br") return "\n";
    if (tag === "pre") return serializeCodeBlock(node);
    if (/^h[1-6]$/.test(tag)) return `${"#".repeat(Number(tag[1]))} ${serializeInlineChildren(node)}`.trim();
    if (tag === "blockquote") {
      return serializeRichText(node).split("\n").map((line) => line ? `> ${line}` : ">").join("\n");
    }
    if (tag === "ul" || tag === "ol") return serializeList(node, tag === "ol");
    if (tag === "li") {
      const marker = listIndex === void 0 ? "-" : `${listIndex}.`;
      return `${marker} ${serializeInlineChildren(node)}`.trim();
    }
    if (tag === "table") return serializeTable(node);
    if (tag === "p") return serializeInlineChildren(node);
    return isBlockElement(node) ? serializeRichText(node) : serializeInlineNode(node);
  }
  function serializeList(list, ordered) {
    return [...list.children].filter((child) => child instanceof HTMLElement && child.tagName.toLowerCase() === "li").map((item, index) => serializeBlock(item, ordered ? index + 1 : void 0)).filter(Boolean).join("\n");
  }
  function serializeCodeBlock(pre) {
    const code = pre.querySelector("code");
    const text = (code?.innerText || pre.innerText || "").replace(/\n+$/g, "");
    return `\`\`\`
${text}
\`\`\``;
  }
  function serializeTable(table) {
    const rows = [...table.querySelectorAll("tr")].map((row) => [...row.children].map((cell) => normalizeInline(cell.innerText || "")).join(" | ")).filter(Boolean);
    return rows.join("\n");
  }
  function serializeInlineChildren(element) {
    return [...element.childNodes].map(serializeInlineNode).join("").replace(/[ \t]+\n/g, "\n").trim();
  }
  function serializeInlineNode(node) {
    if (node.nodeType === Node.TEXT_NODE) return normalizeInline(node.textContent ?? "");
    if (!(node instanceof HTMLElement)) return "";
    const tag = node.tagName.toLowerCase();
    if (tag === "br") return "\n";
    if (tag === "code" && node.closest("pre") === null) return `\`${node.innerText.trim()}\``;
    if (tag === "a") {
      const text = serializeInlineChildren(node) || node.innerText.trim();
      const href = node.getAttribute("href");
      return href && text && href !== text ? `${text} (${href})` : text;
    }
    if (tag === "ul" || tag === "ol" || tag === "pre" || tag === "table" || isBlockElement(node)) {
      return `
${serializeBlock(node)}
`;
    }
    return serializeInlineChildren(node);
  }
  function isBlockElement(element) {
    return /^(article|aside|div|figure|figcaption|footer|header|main|nav|section)$/.test(element.tagName.toLowerCase());
  }
  function normalizeInline(text) {
    return text.replace(/\s+/g, " ");
  }
  async function collectTextResponse(jobId, fallbackText) {
    const assistant = findJobAssistant(jobId);
    if (!assistant) throw new Error("Assistant response was not found.");
    const copyButton = findCopyResponseButton(assistant);
    if (copyButton) {
      copyButton.click();
      await sleep(300);
      for (let attempt = 0; attempt < 10; attempt += 1) {
        const text = await readClipboardText();
        if (text?.trim() && !isAutoChatClipboardText(text)) return text;
        await sleep(200);
      }
    }
    if (fallbackText.trim()) return fallbackText;
    throw new Error(copyButton ? "Copy response produced empty clipboard text." : "Copy response button was not found.");
  }
  function isAutoChatClipboardText(text) {
    return /^auto-chat(?:\s|$)/i.test(text.trim());
  }
  async function readClipboardText() {
    try {
      return await navigator.clipboard.readText();
    } catch {
      return null;
    }
  }
  function findCopyResponseButton(assistant) {
    const buttons = [...assistant.querySelectorAll("button")];
    return buttons.find(
      (button) => button.getAttribute("data-testid") === "copy-turn-action-button"
    ) ?? buttons.find((button) => {
      const label = `${button.innerText} ${button.ariaLabel ?? ""} ${button.title ?? ""}`;
      return /copy response/i.test(label) && !/copy image|copy prompt/i.test(label);
    }) ?? findDoubaoCopyButton(assistant);
  }
  function findDoubaoCopyButton(assistant) {
    if (!assistant.hasAttribute("data-message-id")) return null;
    return assistant.parentElement?.querySelector('[class*="message-action-bar"] button:first-child') ?? null;
  }
  function uniqueImages(images) {
    const seen = /* @__PURE__ */ new Set();
    const unique = [];
    for (const image of images) {
      const key = imageKey(image);
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(image);
    }
    return unique;
  }
  function imageKey(image) {
    const src = image.currentSrc || image.src;
    try {
      const url = new URL(src, location.href);
      return url.searchParams.get("id") ?? src;
    } catch {
      return src;
    }
  }
  function findJobUserTurn(jobId) {
    const message = [...document.querySelectorAll("[data-message-author-role='user'], user-query, [data-message-id]")].find((node) => (node.innerText || "").includes(`JOB_ID: ${jobId}`));
    return message?.closest("section[data-turn='user'], [data-turn='user'], [data-testid^='conversation-turn'], user-query, [data-message-id]") ?? message ?? null;
  }
  function findConversationTurns() {
    const sectionTurns = [...document.querySelectorAll("section[data-turn]")];
    if (sectionTurns.length > 0) return sectionTurns;
    const geminiTurns = [...document.querySelectorAll("user-query, model-response, dual-model-response")];
    if (geminiTurns.length > 0) return geminiTurns;
    const doubaoTurns = [...document.querySelectorAll("[data-message-id]")].filter((row) => (row.innerText || "").trim());
    if (doubaoTurns.length > 0) return doubaoTurns;
    return [...document.querySelectorAll("[data-message-author-role]")];
  }
  function isUserTurn(node) {
    return node.getAttribute("data-turn") === "user" || node.getAttribute("data-message-author-role") === "user" || node.tagName.toLowerCase() === "user-query" || Boolean(node.querySelector("[data-message-author-role='user']")) || node.hasAttribute("data-message-id") && /JOB_ID:/.test(node.innerText || "");
  }
  function isAssistantTurn(node) {
    return node.getAttribute("data-turn") === "assistant" || node.getAttribute("data-message-author-role") === "assistant" || node.tagName.toLowerCase() === "model-response" || node.tagName.toLowerCase() === "dual-model-response" || Boolean(node.querySelector("[data-message-author-role='assistant'], .agent-turn")) || node.hasAttribute("data-message-id") && !isUserTurn(node);
  }
  function isAfter(node, reference) {
    return Boolean(reference.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  function isBefore(node, reference) {
    return Boolean(reference.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_PRECEDING);
  }
  async function waitForComposer() {
    for (let attempt = 0; attempt < 120; attempt += 1) {
      if (findComposer()) return;
      await sleep(500);
    }
    throw new Error(`${platformLabel()} composer was not found.`);
  }
  async function waitForConversationPageReady(job, requireConversationContent = hasRecordedConversation(job)) {
    const readiness = await waitForStableReadiness({
      inspect: () => {
        const composer = findComposer();
        return document.readyState === "complete" && Boolean(composer && isComposerInteractive(composer)) && (!requireConversationContent || findConversationTurns().length > 0);
      },
      sleep
    });
    if (readiness === "timeout") {
      throw new RetryableJobError(`${platformLabel()} conversation did not become stable before prompt submission.`);
    }
  }
  function hasRecordedConversation(job) {
    return Boolean(job.conversationUrl || job.parentJobId);
  }
  function isComposerInteractive(composer) {
    if (!composer.isConnected || !isVisible(composer)) return false;
    if (composer.getAttribute("aria-disabled") === "true" || composer.getAttribute("aria-busy") === "true") return false;
    if (composer instanceof HTMLTextAreaElement) return !composer.disabled && !composer.readOnly;
    return composer.getAttribute("contenteditable") !== "false";
  }
  function isComposerReadyForNextPrompt() {
    const composer = findComposer();
    return Boolean(composer && isComposerInteractive(composer));
  }
  async function uploadSources(job) {
    if (job.sourceImages.length === 0) return;
    let input = document.querySelector('input[type="file"]');
    if (!input && job.platform === "gemini") {
      findUploadMenuButton()?.click();
      await sleep(500);
      input = document.querySelector('input[type="file"]');
    }
    if (!input && job.platform === "doubao") {
      for (let attempt = 0; attempt < 10 && !input; attempt += 1) {
        await sleep(300);
        input = document.querySelector('input[type="file"]');
      }
    }
    if (!input) throw new Error("File input was not found.");
    const files = await Promise.all(job.sourceImages.map((source, index) => sourceToFile(source, index)));
    const transfer = new DataTransfer();
    for (const file of files) transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await sleep(1500);
  }
  async function pasteGeminiSources(job, composer) {
    if (job.sourceImages.length === 0) return;
    const files = await Promise.all(job.sourceImages.map((source, index) => sourceToFile(source, index)));
    const transfer = new DataTransfer();
    for (const file of files) transfer.items.add(file);
    const event = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      clipboardData: transfer
    });
    composer.focus();
    composer.dispatchEvent(event);
    await sleep(500);
  }
  async function fillPromptAndSendGpt(job, requireNewUserTurn = false) {
    const { prompt } = job;
    const isNewConversation = !hasRecordedConversation(job);
    const capture = isNewConversation ? startGptConversationUrlCapture() : null;
    const existingUserTurnCount = requireNewUserTurn ? countJobUserTurns(job.id) : 0;
    try {
      const composer = fillPrompt(prompt);
      await sleep(300);
      const sendButton = findSendButton();
      if (await submitPromptWithFallback({
        composer,
        sendButton,
        getSendButton: findSendButton,
        isSubmitted: async () => requireNewUserTurn ? countJobUserTurns(job.id) > existingUserTurnCount : isPromptSubmitted(prompt),
        onWaitingForSubmitReady: () => report(job.id, "waiting_upload_ready"),
        sleep
      })) return;
      const capturedUrl = capture?.getUrl() ?? null;
      if (shouldReloadCapturedConversation({ capturedUrl, currentPathname: location.pathname })) {
        location.href = capturedUrl;
        if (await waitForReloadConversation(job.id)) return;
      }
      throw new RetryableJobError(`Prompt was filled but no submitted ${platformLabel()} user turn appeared.`);
    } finally {
      capture?.stop();
    }
  }
  function startGptConversationUrlCapture() {
    let capturedUrl = null;
    const capture = () => {
      const normalizedUrl = normalizeGptConversationUrl(location.href);
      if (!capturedUrl && normalizedUrl && isGptConversationPath(location.pathname)) capturedUrl = normalizedUrl;
    };
    const originalPushState = history.pushState.bind(history);
    const originalReplaceState = history.replaceState.bind(history);
    history.pushState = ((...args) => {
      originalPushState(...args);
      capture();
    });
    history.replaceState = ((...args) => {
      originalReplaceState(...args);
      capture();
    });
    let stopped = false;
    return {
      getUrl: () => {
        capture();
        return capturedUrl;
      },
      stop: () => {
        if (stopped) return;
        stopped = true;
        history.pushState = originalPushState;
        history.replaceState = originalReplaceState;
      }
    };
  }
  async function fillPromptAndSendDoubao(job) {
    const { prompt } = job;
    const isNewConversation = !hasRecordedConversation(job);
    const capture = isNewConversation ? startGptConversationUrlCapture() : null;
    try {
      if (job.mode === "image") {
        await enterDoubaoImageMode();
        const model = readDoubaoModel(job.metadata);
        if (model) await selectDoubaoModel(model, DOUBAO_MODEL_TRIGGER_SELECTOR);
      }
      if (job.mode === "video") {
        await enterDoubaoVideoMode();
        const model = readDoubaoModel(job.metadata);
        if (model) await selectDoubaoModel(model, DOUBAO_VIDEO_MODEL_TRIGGER_SELECTOR);
        await applyDoubaoVideoParams(job);
      }
      const composer = fillPrompt(prompt);
      await sleep(300);
      const sendButton = findDoubaoSendButton();
      if (await submitPromptWithFallback({
        composer,
        sendButton,
        getSendButton: findDoubaoSendButton,
        isSubmitted: () => isPromptSubmitted(prompt),
        onWaitingForSubmitReady: () => report(job.id, "waiting_upload_ready"),
        sleep
      })) return;
      const capturedUrl = capture?.getUrl() ?? null;
      if (shouldReloadCapturedConversation({ capturedUrl, currentPathname: location.pathname })) {
        location.href = capturedUrl;
        if (await waitForReloadConversation(job.id)) return;
      }
      throw new RetryableJobError("Prompt was filled but no submitted \u8C46\u5305 user turn appeared.");
    } finally {
      capture?.stop();
    }
  }
  async function enterDoubaoImageMode() {
    if (isDoubaoImageModeActive()) return;
    const button = findDoubaoToolbarButton("\u56FE\u50CF\u751F\u6210");
    if (!button) throw new Error("\u8C46\u5305\u300C\u56FE\u50CF\u751F\u6210\u300D\u6309\u94AE\u672A\u627E\u5230\u3002");
    button.click();
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (isDoubaoImageModeActive()) return;
      await sleep(300);
    }
    throw new Error("\u70B9\u51FB\u300C\u56FE\u50CF\u751F\u6210\u300D\u540E\u672A\u80FD\u8FDB\u5165\u56FE\u7247\u751F\u6210\u6A21\u5F0F\u3002");
  }
  function isDoubaoImageModeActive() {
    const placeholderEl = document.querySelector("[data-placeholder]");
    return placeholderEl?.getAttribute("data-placeholder") === "\u63CF\u8FF0\u4F60\u60F3\u8981\u7684\u56FE\u7247";
  }
  async function enterDoubaoVideoMode() {
    if (isDoubaoVideoModeActive()) return;
    const button = findDoubaoToolbarButton("\u89C6\u9891\u751F\u6210");
    if (!button) throw new Error("\u8C46\u5305\u300C\u89C6\u9891\u751F\u6210\u300D\u6309\u94AE\u672A\u627E\u5230\u3002");
    button.click();
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (isDoubaoVideoModeActive()) return;
      await sleep(300);
    }
    throw new Error("\u70B9\u51FB\u300C\u89C6\u9891\u751F\u6210\u300D\u540E\u672A\u80FD\u8FDB\u5165\u89C6\u9891\u751F\u6210\u6A21\u5F0F\u3002");
  }
  function isDoubaoVideoModeActive() {
    const placeholderEl = document.querySelector("[data-placeholder]");
    return placeholderEl?.getAttribute("data-placeholder") === "\u63CF\u8FF0\u4F60\u60F3\u8981\u7684\u89C6\u9891";
  }
  var DOUBAO_MODEL_TRIGGER_SELECTOR = "[data-input-engine-actionbar-control-key='model']";
  var DOUBAO_VIDEO_MODEL_TRIGGER_SELECTOR = "[data-input-engine-actionbar-control-key='video-model']";
  var DOUBAO_VIDEO_PARAMS_TRIGGER_SELECTOR = "[data-input-engine-actionbar-render-entry-key='video-generation-params-panel']";
  var DOUBAO_VIDEO_PARAMS_PANEL_SELECTOR = "[data-slot='dropdown-menu-content'][data-creation-params-panel-id]";
  var DOUBAO_MENU_SELECTOR = "[role='menu'][data-slot='dropdown-menu-content']";
  var DOUBAO_MENU_ITEM_SELECTOR = "[role='menuitem'][data-slot='dropdown-menu-item']";
  async function applyDoubaoVideoParams(job) {
    const ratio = readDoubaoVideoRatio(job.metadata);
    const seconds = readDoubaoVideoDurationSeconds(job.metadata);
    if (!ratio && seconds === void 0) return;
    const trigger = document.querySelector(DOUBAO_VIDEO_PARAMS_TRIGGER_SELECTOR);
    if (!trigger) throw new Error("\u8C46\u5305\u89C6\u9891\u300C\u6BD4\u4F8B \xB7 \u65F6\u957F\u300D\u6309\u94AE\u672A\u627E\u5230\uFF0C\u53EF\u80FD\u4E0D\u5728\u89C6\u9891\u751F\u6210\u6A21\u5F0F\u3002");
    if (isDoubaoVideoParamsApplied(trigger.innerText ?? "", { ratio, seconds })) return;
    clickDoubaoControl(trigger);
    const panel = await waitUntilTruthy(() => {
      const element = document.querySelector(DOUBAO_VIDEO_PARAMS_PANEL_SELECTOR);
      return element && isPresentInLayout(element) ? element : null;
    }, 5e3);
    if (!panel) throw new Error("\u70B9\u51FB\u300C\u6BD4\u4F8B \xB7 \u65F6\u957F\u300D\u540E\u53C2\u6570\u9762\u677F\u672A\u51FA\u73B0\u3002");
    try {
      if (ratio) await selectDoubaoVideoRatio(panel, ratio);
      if (seconds !== void 0) await setDoubaoVideoDuration(panel, seconds);
    } catch (error) {
      closeDoubaoDropdown();
      throw error;
    }
    closeDoubaoDropdown();
    const applied = await waitUntilTruthy(() => {
      const current = document.querySelector(DOUBAO_VIDEO_PARAMS_TRIGGER_SELECTOR);
      return current && isDoubaoVideoParamsApplied(current.innerText ?? "", { ratio, seconds }) ? current : null;
    }, 5e3);
    if (!applied) {
      const current = document.querySelector(DOUBAO_VIDEO_PARAMS_TRIGGER_SELECTOR)?.innerText ?? "";
      const parsed = parseDoubaoVideoParamsTrigger(current);
      const wanted = [ratio ?? "\uFF08\u4E0D\u6539\uFF09", seconds === void 0 ? "\uFF08\u4E0D\u6539\uFF09" : `${seconds}s`].join(" \xB7 ");
      throw new Error(
        `\u8C46\u5305\u89C6\u9891\u53C2\u6570\u672A\u8BBE\u7F6E\u6210\u300C${wanted}\u300D\uFF0C\u5F53\u524D\u662F\u300C${parsed ? `${parsed.ratio} \xB7 ${parsed.seconds}s` : current.trim() || "\u672A\u77E5"}\u300D\u3002`
      );
    }
  }
  async function selectDoubaoVideoRatio(panel, ratio) {
    const buttons = [...panel.querySelectorAll("div.grid button")].filter((button) => isPresentInLayout(button));
    const match = matchDoubaoVideoRatioOption(buttons.map((button) => button.innerText ?? ""), ratio);
    if ("errorMessage" in match) throw new Error(match.errorMessage);
    buttons[match.index].click();
    await sleep(200);
  }
  async function setDoubaoVideoDuration(panel, seconds) {
    const thumb = panel.querySelector("[data-slot='slider-thumb'][role='slider']");
    if (!thumb) throw new Error("\u8C46\u5305\u89C6\u9891\u65F6\u957F\u6ED1\u5757\u672A\u627E\u5230\u3002");
    const wanted = doubaoVideoSliderValue(seconds);
    thumb.focus();
    for (let guard = 0; guard < 32; guard += 1) {
      const now = Number(thumb.getAttribute("aria-valuenow"));
      if (!Number.isFinite(now)) throw new Error("\u8C46\u5305\u89C6\u9891\u65F6\u957F\u6ED1\u5757\u6CA1\u6709 aria-valuenow\u3002");
      if (now === wanted) return;
      const key = now > wanted ? "ArrowLeft" : "ArrowRight";
      thumb.dispatchEvent(new KeyboardEvent("keydown", { key, code: key, bubbles: true, cancelable: true }));
      thumb.dispatchEvent(new KeyboardEvent("keyup", { key, code: key, bubbles: true, cancelable: true }));
      await sleep(120);
    }
    throw new Error(`\u8C46\u5305\u89C6\u9891\u65F6\u957F\u672A\u80FD\u8C03\u5230 ${seconds}s\u3002`);
  }
  async function selectDoubaoModel(model, triggerSelector) {
    const trigger = document.querySelector(triggerSelector);
    if (!trigger) throw new Error("\u8C46\u5305\u300C\u6A21\u578B\u300D\u6309\u94AE\u672A\u627E\u5230\uFF0C\u53EF\u80FD\u4E0D\u5728\u5BF9\u5E94\u7684\u751F\u6210\u6A21\u5F0F\u3002");
    if (isDoubaoModelSelected(trigger.innerText ?? "", model)) return;
    clickDoubaoControl(trigger);
    const menu = await waitUntilTruthy(() => {
      const element = document.querySelector(DOUBAO_MENU_SELECTOR);
      return element && isPresentInLayout(element) ? element : null;
    }, 5e3);
    if (!menu) throw new Error("\u70B9\u51FB\u300C\u6A21\u578B\u300D\u540E\u4E0B\u62C9\u83DC\u5355\u672A\u51FA\u73B0\u3002");
    try {
      const options = [...menu.querySelectorAll(DOUBAO_MENU_ITEM_SELECTOR)];
      const match = matchDoubaoModelOption(options.map((option) => option.innerText ?? ""), model);
      if ("errorMessage" in match) throw new Error(match.errorMessage);
      clickDoubaoControl(options[match.index]);
    } catch (error) {
      closeDoubaoDropdown();
      throw error;
    }
    const applied = await waitUntilTruthy(() => {
      const current = document.querySelector(triggerSelector);
      return current && isDoubaoModelSelected(current.innerText ?? "", model) ? current : null;
    }, 5e3);
    if (!applied) {
      closeDoubaoDropdown();
      const current = doubaoModelTriggerName(
        document.querySelector(triggerSelector)?.innerText ?? ""
      );
      throw new Error(`\u8C46\u5305\u6A21\u578B\u672A\u5207\u6362\u5230\u300C${model}\u300D\uFF0C\u5F53\u524D\u4ECD\u662F\u300C${current || "\u672A\u77E5"}\u300D\uFF0C\u53EF\u80FD\u9700\u8981\u66F4\u9AD8\u6743\u76CA\u3002`);
    }
  }
  function clickDoubaoControl(element) {
    element.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
    element.click();
  }
  function closeDoubaoDropdown() {
    if (!document.querySelector(DOUBAO_MENU_SELECTOR)) return;
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
  }
  function findDoubaoToolbarButton(label) {
    return [...document.querySelectorAll("button")].find((button) => isVisible(button) && button.innerText?.trim() === label) ?? null;
  }
  function findDoubaoSendButton() {
    return [...document.querySelectorAll("button")].find((button) => isVisible(button) && getComputedStyle(button).backgroundColor === DOUBAO_BRAND_BLUE) ?? null;
  }
  async function waitForDoubaoUploadReady(jobId) {
    await report(jobId, "waiting_upload_ready");
    for (let attempt = 0; attempt < 120; attempt += 1) {
      if (findDoubaoSendButton()) return;
      await sleep(500);
    }
    throw new Error("\u8C46\u5305\u56FE\u7247\u4E0A\u4F20\u672A\u5728\u8D85\u65F6\u524D\u5B8C\u6210\u3002");
  }
  async function fillPromptPasteSourcesAndSendGemini(job, prompt) {
    await report(job.id, "sending_prompt");
    const composer = fillPrompt(prompt);
    if (job.sourceImages.length > 0) {
      await report(job.id, "uploading");
      await pasteGeminiSources(job, composer);
      await waitForGeminiUploadReady(job.id);
    }
    if (await submitGeminiPromptWithFallback(job, composer, prompt)) return;
    if (job.sourceImages.length > 0) {
      throw new RetryableJobError("Gemini send control was not ready after image upload.");
    }
    throw new RetryableJobError(`Prompt was filled but no submitted Gemini user turn appeared.`);
  }
  async function submitGeminiPromptWithFallback(job, composer, prompt) {
    let reportedWaiting = false;
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const sendControl = findGeminiSendControl();
      if (sendControl && !isGeminiSendDisabled(sendControl)) {
        clickGeminiSendControl(sendControl);
        if (await waitForSubmittedPrompt(prompt, 4, 250)) return true;
      } else if (!reportedWaiting) {
        reportedWaiting = true;
        await report(job.id, "waiting_upload_ready");
      }
      dispatchGeminiEnter(composer);
      if (await waitForSubmittedPrompt(prompt, 2, 250)) return true;
      await sleep(250);
    }
    return false;
  }
  function clickGeminiSendControl(control) {
    const target = control.querySelector("button:not([disabled]), [role='button']:not([aria-disabled='true'])") ?? control;
    target.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true }));
    target.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    target.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, cancelable: true }));
    target.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
    target.click();
  }
  function dispatchGeminiEnter(composer) {
    composer.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    composer.dispatchEvent(new KeyboardEvent("keypress", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    composer.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
  }
  async function waitForSubmittedPrompt(prompt, attempts, delayMs) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      if (await isPromptSubmitted(prompt)) return true;
      await sleep(delayMs);
    }
    return false;
  }
  async function waitForGeminiUploadReady(jobId) {
    await report(jobId, "waiting_upload_ready");
    for (let attempt = 0; attempt < 120; attempt += 1) {
      const sendControl = findGeminiSendControl();
      if (sendControl && !isGeminiSendDisabled(sendControl)) return;
      await sleep(500);
    }
    throw new Error("Gemini image upload did not finish before timeout.");
  }
  function fillPrompt(prompt) {
    const composer = findComposer();
    if (!composer) throw new Error("Composer was not found.");
    composer.focus();
    if (composer instanceof HTMLTextAreaElement) {
      composer.value = prompt;
      composer.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      selectEditableContents(composer);
      if (!document.execCommand("insertText", false, prompt)) {
        composer.textContent = prompt;
        composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt }));
      }
    }
    return composer;
  }
  function findComposer() {
    return findVisibleElement('[contenteditable="true"][aria-label="Enter a prompt for Gemini"]') || findVisibleElement("rich-textarea .ql-editor[role='textbox']") || findVisibleElement('[contenteditable="true"][role="textbox"]') || findVisibleElement('[contenteditable="true"]') || findVisibleElement("textarea");
  }
  function findSendButton() {
    const buttons = [...document.querySelectorAll("button")];
    return buttons.find((button) => {
      const label = `${button.innerText} ${button.ariaLabel ?? ""} ${button.title ?? ""}`;
      const testId = button.getAttribute("data-testid") ?? "";
      return isVisible(button) && (/send|submit|发送/i.test(label) || testId.includes("send")) && !/stop|microphone|麦克风/i.test(label) && testId !== "stop-button";
    }) ?? null;
  }
  function hasOnlyResponseActionMenu(jobId) {
    const assistant = findJobAssistant(jobId);
    if (!assistant) return false;
    const actions = [...assistant.querySelectorAll('[aria-label="Response actions"] button')].filter(isVisible);
    return actions.length === 1 && actions[0]?.getAttribute("aria-haspopup") === "menu";
  }
  function hasActiveGenerationControl() {
    return Boolean(findActiveGenerationControl());
  }
  function stopActiveGptGeneration() {
    const button = findActiveGenerationControl();
    if (!button || button.disabled || button.getAttribute("aria-disabled") === "true") return false;
    button.click();
    return true;
  }
  function findActiveGenerationControl() {
    return [...document.querySelectorAll("button")].find((button) => {
      const label = `${button.innerText} ${button.ariaLabel ?? ""} ${button.title ?? ""}`;
      return isVisible(button) && isGenerationStopControl(button.getAttribute("data-testid"), label);
    }) ?? null;
  }
  function findUploadMenuButton() {
    return [...document.querySelectorAll("button")].find((button) => {
      const label = `${button.innerText} ${button.ariaLabel ?? ""} ${button.title ?? ""}`;
      return isVisible(button) && /upload and tools|上传/i.test(label);
    }) ?? null;
  }
  function selectEditableContents(element) {
    const range = document.createRange();
    range.selectNodeContents(element);
    const selection = getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
  }
  function findVisibleElement(selector) {
    return [...document.querySelectorAll(selector)].find(isVisible) ?? null;
  }
  function isVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }
  async function isPromptSubmitted(prompt) {
    const jobId = prompt.match(/JOB_ID:\s*([^\s]+)/)?.[1];
    return !jobId || Boolean(findJobUserTurn(jobId));
  }
  async function sourceToFile(source, index) {
    const response = await fetch(source);
    const blob = await response.blob();
    const ext = blob.type.includes("jpeg") ? "jpg" : blob.type.includes("webp") ? "webp" : "png";
    return new File([blob], `source-${index + 1}.${ext}`, { type: blob.type || "image/png" });
  }
  async function collectImages(images) {
    const result = [];
    for (const [index, image] of images.entries()) {
      const { blob, acquisition } = await fetchBestImageBlob(image);
      const sourceId = imageKey(image);
      const sha256 = await sha256Blob(blob);
      const contentType = blob.type || "image/png";
      if (activeJob) {
        await traceJob(activeJob.id, "image_asset_collected", {
          index: index + 1,
          sourceId,
          acquisition,
          byteLength: blob.size,
          contentType,
          sha256
        });
      }
      result.push({
        index,
        sourceId,
        contentType,
        byteLength: blob.size,
        sha256,
        acquisition,
        dataUrl: await blobToDataUrl(blob)
      });
    }
    return result;
  }
  async function sha256Blob(blob) {
    const digest = await crypto.subtle.digest("SHA-256", await blob.arrayBuffer());
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  async function fetchBestImageBlob(image) {
    if (activeJob?.platform === "gemini") {
      return { blob: await downloadGeminiFullSizeImage(image), acquisition: "gemini_download" };
    }
    if (activeJob?.platform === "doubao") {
      return { blob: await downloadDoubaoImage(image), acquisition: "doubao_download" };
    }
    if (activeJob?.platform === "gpt") {
      try {
        const blob = await fetchImageElementBlob(image);
        await debugLog("fetchBestImageBlob:gpt direct image fetch succeeded", { sourceId: imageKey(image), size: blob.size, type: blob.type });
        return { blob, acquisition: "gpt_direct" };
      } catch (error) {
        await debugLog("fetchBestImageBlob:gpt direct image fetch failed, trying share sheet", { sourceId: imageKey(image), error: String(error) });
      }
      try {
        const blob = await downloadGptFullSizeImage(image);
        await debugLog("fetchBestImageBlob:gpt share sheet download succeeded", { sourceId: imageKey(image), size: blob.size, type: blob.type });
        return { blob, acquisition: "gpt_share_sheet" };
      } catch (error) {
        await debugLog("fetchBestImageBlob:gpt share sheet download failed, falling back", { sourceId: imageKey(image), error: String(error) });
      }
    }
    return { blob: await fetchImageElementBlob(image), acquisition: "element_url" };
  }
  async function fetchImageElementBlob(image) {
    for (const source of imageCandidates(image)) {
      try {
        const response2 = await fetch(source);
        if (!response2.ok && !source.startsWith("blob:") && !source.startsWith("data:")) continue;
        const blob2 = await response2.blob();
        if (blob2.size > 0) return blob2;
      } catch {
      }
    }
    const response = await fetch(image.currentSrc || image.src);
    const blob = await response.blob();
    if (blob.size === 0) throw new Error("Image element source returned an empty response.");
    return blob;
  }
  async function requestTrustedClickDownload(point, failureLabel) {
    return new Promise((resolve, reject) => {
      const port = chrome.runtime.connect({ name: "image-download-capture" });
      let settled = false;
      const finishOk = (blob) => {
        if (settled) return;
        settled = true;
        port.disconnect();
        resolve(blob);
      };
      const finishError = (message) => {
        if (settled) return;
        settled = true;
        port.disconnect();
        reject(new Error(message));
      };
      port.onMessage.addListener((message) => {
        if (message.type === "RESULT") {
          if (message.ok && message.contentType && message.base64) {
            finishOk(base64ToBlob(message.base64, message.contentType));
          } else {
            finishError(message.error || `${failureLabel} failed for an unknown reason.`);
          }
        }
      });
      port.onDisconnect.addListener(() => {
        finishError("Connection to the extension background script was lost before the download completed.");
      });
      port.postMessage({ type: "REQUEST_IMAGE_DOWNLOAD", point });
    });
  }
  async function requestHoverClickDownload(hoverPoint, measureClickPoint, failureLabel) {
    return new Promise((resolve, reject) => {
      const port = chrome.runtime.connect({ name: "image-download-capture" });
      let settled = false;
      const finishOk = (blob) => {
        if (settled) return;
        settled = true;
        port.disconnect();
        resolve(blob);
      };
      const finishError = (message) => {
        if (settled) return;
        settled = true;
        port.disconnect();
        reject(new Error(message));
      };
      port.onMessage.addListener((message) => {
        if (message.type === "HOVER_READY") {
          void measureClickPoint().then((point) => port.postMessage({ type: "CLICK_AT", point })).catch(() => port.postMessage({ type: "CLICK_AT", point: null }));
          return;
        }
        if (message.type === "RESULT") {
          if (message.ok && message.contentType && message.base64) {
            finishOk(base64ToBlob(message.base64, message.contentType));
          } else {
            finishError(message.error || `${failureLabel} failed for an unknown reason.`);
          }
        }
      });
      port.onDisconnect.addListener(() => {
        finishError("Connection to the extension background script was lost before the download completed.");
      });
      port.postMessage({ type: "REQUEST_HOVER_DOWNLOAD", hoverPoint });
    });
  }
  function elementCenterPoint(element) {
    element.scrollIntoView({ block: "center", inline: "center" });
    return elementViewportPoint(element);
  }
  function elementViewportPoint(element) {
    const rect = element.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return null;
    return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
  }
  async function downloadGeminiFullSizeImage(image) {
    const button = findGeminiDownloadButton(image);
    if (!button) throw new Error(`Gemini's "Download full-sized image" button was not found for this image.`);
    const point = elementCenterPoint(button);
    if (!point) throw new Error(`Gemini's "Download full-sized image" button has no on-screen position to click.`);
    return requestTrustedClickDownload(point, "Gemini full-size image download");
  }
  async function downloadDoubaoImage(image) {
    image.scrollIntoView({ block: "center", inline: "center" });
    image.click();
    const saveButton = await waitUntilTruthy(findDoubaoPreviewSaveButton, 5e3);
    await debugLog("findDoubaoPreviewSaveButton", {
      found: Boolean(saveButton),
      previewOpen: isDoubaoImagePreviewOpen(),
      byIcon: saveButton ? hasDoubaoDownloadIcon(saveButton) : false
    });
    if (!saveButton) throw new Error("Doubao's image preview save button was not found.");
    try {
      const point = elementCenterPoint(saveButton);
      await debugLog("doubaoPreviewSaveButtonPoint", { point });
      if (!point) throw new Error("Doubao's image preview save button has no on-screen position to click.");
      const blob = await requestTrustedClickDownload(point, "Doubao image download");
      await debugLog("fetchBestImageBlob:doubao real download succeeded", { size: blob.size, type: blob.type });
      return blob;
    } finally {
      closeDoubaoImagePreview();
    }
  }
  var DOUBAO_VIDEO_CARD_SELECTOR = "[class*='block-video-']";
  var DOUBAO_VIDEO_HOVER_GROUP_SELECTOR = "[class*='video-hover-button-group-']";
  function findDoubaoVideoCards(root) {
    return [...root.querySelectorAll(DOUBAO_VIDEO_CARD_SELECTOR)].filter((card) => isPresentInLayout(card)).filter((card) => Boolean(card.querySelector("img[class*='cover-']")));
  }
  function findJobScopedVideoCards(jobId) {
    const scope = findJobConversationScope(jobId);
    if (!scope) return [];
    return findDoubaoVideoCards(document).filter(
      (card) => !scope.user.contains(card) && isAfter(card, scope.user) && (!scope.nextUser || isBefore(card, scope.nextUser))
    );
  }
  async function collectVideos(cards) {
    const result = [];
    for (const [index, card] of cards.entries()) {
      const blob = await downloadDoubaoVideo(card);
      const contentType = blob.type.startsWith("video/") ? blob.type : "video/mp4";
      const sha256 = await sha256Blob(blob);
      const sourceId = card.querySelector("img[class*='cover-']")?.currentSrc || `video-${index + 1}`;
      if (activeJob) {
        await traceJob(activeJob.id, "video_asset_collected", {
          index: index + 1,
          sourceId,
          acquisition: "doubao_video_download",
          byteLength: blob.size,
          contentType,
          sha256
        });
      }
      result.push({
        index,
        sourceId,
        contentType,
        byteLength: blob.size,
        sha256,
        acquisition: "doubao_video_download",
        dataUrl: await blobToDataUrl(blob)
      });
    }
    return result;
  }
  async function downloadDoubaoVideo(card) {
    const direct = await fetchDoubaoVideoBySource(card);
    if (direct) return direct;
    const hoverPoint = elementCenterPoint(card);
    if (!hoverPoint) throw new Error("\u8C46\u5305\u89C6\u9891\u5361\u7247\u6CA1\u6709\u53EF\u60AC\u505C\u7684\u5C4F\u5E55\u5750\u6807\u3002");
    await sleep(200);
    const blob = await requestHoverClickDownload(hoverPoint, async () => {
      hoverDoubaoVideoCard(card);
      const action = await waitForDoubaoVideoDownloadAction(card, 8e3);
      await debugLog("findDoubaoVideoDownloadAction", { found: Boolean(action) });
      if (!action) {
        if (activeJob) {
          await traceJob(activeJob.id, "doubao_video_card_probe", describeDoubaoVideoCard(card));
        }
        return null;
      }
      const point = elementViewportPoint(action);
      const hit = point ? document.elementFromPoint(point.x, point.y) : null;
      await debugLog("doubaoVideoDownloadActionPoint", {
        point,
        action: describeNodeForTrace(action),
        hit: hit instanceof HTMLElement ? describeNodeForTrace(hit) : null,
        hitIsAction: Boolean(hit && (action.contains(hit) || hit.contains(action)))
      });
      return point;
    }, "Doubao video download");
    await debugLog("downloadDoubaoVideo succeeded", { size: blob.size, type: blob.type });
    if (blob.size === 0) throw new Error("\u8C46\u5305\u89C6\u9891\u4E0B\u8F7D\u5F97\u5230\u7684\u662F\u7A7A\u6587\u4EF6\u3002");
    return blob;
  }
  async function fetchDoubaoVideoBySource(card) {
    const src = await waitUntilTruthy(() => {
      hoverDoubaoVideoCard(card);
      const video = card.querySelector("video");
      const candidate = video?.currentSrc || video?.getAttribute("src") || "";
      return candidate.startsWith("http") ? candidate : null;
    }, 6e3);
    const described = src ? describeMediaUrl(src) : null;
    await debugLog("doubaoVideoSource", { found: Boolean(src), ...described });
    if (!src) return null;
    const response = await chrome.runtime.sendMessage({ type: "FETCH_MEDIA", url: src });
    if (!response?.ok || !response.base64) {
      await debugLog("doubaoVideoSourceFetchFailed", { error: response?.error ?? "no_response" });
      return null;
    }
    const contentType = response.contentType?.startsWith("video/") ? response.contentType : "video/mp4";
    const blob = base64ToBlob(response.base64, contentType);
    await debugLog("doubaoVideoSourceFetched", { size: blob.size, type: blob.type });
    if (blob.size === 0) return null;
    if (activeJob) {
      await traceJob(activeJob.id, "doubao_video_direct_source_used", { ...described, byteLength: blob.size });
    }
    return blob;
  }
  function describeMediaUrl(raw) {
    try {
      const url = new URL(raw);
      return { host: url.host, path: url.pathname.slice(0, 120) };
    } catch {
      return { host: null, path: null };
    }
  }
  async function waitForDoubaoVideoDownloadAction(card, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      hoverDoubaoVideoCard(card);
      const action = findDoubaoVideoDownloadAction(card);
      if (action) return action;
      await sleep(300);
    }
    return findDoubaoVideoDownloadAction(card);
  }
  function hoverDoubaoVideoCard(card) {
    const rect = card.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2
    };
    card.dispatchEvent(new PointerEvent("pointerover", init));
    card.dispatchEvent(new MouseEvent("mouseover", init));
    card.dispatchEvent(new PointerEvent("pointerenter", { ...init, bubbles: false }));
    card.dispatchEvent(new MouseEvent("mouseenter", { ...init, bubbles: false }));
    card.dispatchEvent(new PointerEvent("pointermove", init));
    card.dispatchEvent(new MouseEvent("mousemove", init));
  }
  var DOUBAO_VIDEO_ACTION_MAX_SIZE_PX = 64;
  function findDoubaoVideoDownloadAction(card) {
    const scopes = [
      ...card.querySelectorAll(DOUBAO_VIDEO_HOVER_GROUP_SELECTOR),
      card
    ].filter(isPresentInLayout);
    for (const scope of scopes) {
      const candidates = [...scope.querySelectorAll("*")].filter(isDoubaoVideoActionCandidate).filter((element) => hasDoubaoVideoDownloadIcon(element) || hasDoubaoDownloadIcon(element) || isDoubaoDownloadControl(element));
      const innermost = candidates.find((element) => !candidates.some((other) => other !== element && element.contains(other)));
      if (innermost) return innermost.closest("button,[role='button']") ?? innermost;
    }
    return null;
  }
  function isDoubaoVideoActionCandidate(element) {
    if (!element.querySelector("svg")) return false;
    if (!isPresentInLayout(element)) return false;
    const rect = element.getBoundingClientRect();
    return rect.width <= DOUBAO_VIDEO_ACTION_MAX_SIZE_PX && rect.height <= DOUBAO_VIDEO_ACTION_MAX_SIZE_PX;
  }
  function describeDoubaoVideoCard(card) {
    const nodes = [...card.querySelectorAll("*")];
    return {
      cardClass: elementClassName(card).slice(0, 120),
      nodeCount: nodes.length,
      hasVideoElement: Boolean(card.querySelector("video")),
      hoverGroups: nodes.filter((node) => node.matches(DOUBAO_VIDEO_HOVER_GROUP_SELECTOR)).map(describeNodeForTrace),
      iconNodes: nodes.filter((node) => node.matches(":has(> svg)")).slice(0, 20).map(describeNodeForTrace),
      clickable: nodes.filter((node) => isPresentInLayout(node) && isLikelyClickable(node)).slice(0, 20).map(describeNodeForTrace),
      svgPaths: [...card.querySelectorAll("svg path")].slice(0, 20).map((path) => (path.getAttribute("d") ?? "").slice(0, 28))
    };
  }
  function describeNodeForTrace(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return [
      element.tagName.toLowerCase(),
      elementClassName(element).slice(0, 48),
      `${Math.round(rect.width)}x${Math.round(rect.height)}@${Math.round(rect.x)},${Math.round(rect.y)}`,
      `op=${style.opacity}`,
      `vis=${style.visibility}`,
      `cur=${style.cursor}`
    ].filter(Boolean).join("|");
  }
  function elementClassName(element) {
    return typeof element.className === "string" ? element.className : String(element.getAttribute("class") ?? "");
  }
  async function downloadGptFullSizeImage(image) {
    const shareButton = findGptShareButton(image);
    await debugLog("findGptShareButton", { found: Boolean(shareButton) });
    if (!shareButton) throw new Error(`ChatGPT's "Share this image" button was not found for this image.`);
    shareButton.click();
    const dialog = await waitUntilTruthy(() => findVisibleElement("[role='dialog'][aria-description='Share sheet']"), 5e3);
    await debugLog("shareDialog", { found: Boolean(dialog) });
    if (!dialog) throw new Error("ChatGPT's share sheet did not open.");
    try {
      const downloadButton = await waitUntilTruthy(() => findGptShareSheetDownloadButton(dialog), 5e3);
      await debugLog("shareSheetDownloadButton", { found: Boolean(downloadButton) });
      if (!downloadButton) throw new Error(`ChatGPT's share sheet "Download" button was not found.`);
      await sleep(400);
      const point = elementCenterPoint(downloadButton);
      await debugLog("downloadButtonPoint", { point });
      if (!point) throw new Error(`ChatGPT's share sheet "Download" button has no on-screen position to click.`);
      const blob = await requestTrustedClickDownload(point, "ChatGPT full-size image download");
      await debugLog("requestTrustedClickDownload", { ok: true, size: blob.size, type: blob.type });
      return blob;
    } catch (error) {
      await debugLog("downloadGptFullSizeImage failed", { error: String(error) });
      throw error;
    } finally {
      dialog.querySelector("[data-testid='close-button']")?.click();
    }
  }
  async function waitUntilTruthy(check, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const value = check();
      if (value) return value;
      await sleep(150);
    }
    return check();
  }
  function findGeminiDownloadButton(image) {
    const container = image.closest(".group\\/imagegen-image, [id^='image-'], generated-image, single-image") ?? image.parentElement;
    if (!container) return null;
    const candidates = [...container.querySelectorAll("button,[role='button'],a")];
    return candidates.find((element) => {
      const label = `${element.getAttribute("aria-label") ?? ""} ${element.title ?? ""} ${element.innerText ?? ""}`;
      return isPresentInLayout(element) && /download full|download full-sized image|下载原图|下载完整/i.test(label);
    }) ?? null;
  }
  function findDoubaoPreviewSaveButton() {
    const candidates = [...document.querySelectorAll("button,[role='button'],a")].filter(isPresentInLayout);
    const iconHits = candidates.filter(hasDoubaoDownloadIcon);
    const innermostIconHit = iconHits.find((element) => !iconHits.some((other) => other !== element && element.contains(other)));
    if (innermostIconHit) return innermostIconHit;
    const labelled = candidates.find(isDoubaoDownloadControl);
    if (labelled) return labelled;
    if (!isDoubaoImagePreviewOpen()) return null;
    const blue = candidates.filter((element) => getComputedStyle(element).backgroundColor === DOUBAO_BRAND_BLUE);
    return blue.length === 1 ? blue[0] : null;
  }
  function isDoubaoImagePreviewOpen() {
    return [...document.querySelectorAll(DOUBAO_PREVIEW_MARKER_SELECTOR)].some(isPresentInLayout);
  }
  function closeDoubaoImagePreview() {
    const closeButton = [...document.querySelectorAll("button,[role='button']")].find((element) => isPresentInLayout(element) && /close|\u5173\u95ed/i.test(elementAccessibleLabel(element)));
    if (closeButton) {
      closeButton.click();
      return;
    }
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
  }
  function isPresentInLayout(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }
  function base64ToBlob(base64, contentType) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: contentType });
  }
  function findGptShareButton(image) {
    const container = image.closest(".group\\/imagegen-image, [id^='image-']") ?? image.parentElement;
    if (!container) return null;
    const candidates = [...container.querySelectorAll("button,[role='button']")];
    return candidates.find((element) => isPresentInLayout(element) && /share this image/i.test(elementAccessibleLabel(element))) ?? null;
  }
  function findGptShareSheetDownloadButton(dialog) {
    const candidates = [...dialog.querySelectorAll("button,[role='button']")];
    return candidates.find((element) => isPresentInLayout(element) && /^download$/i.test((element.innerText ?? "").trim())) ?? null;
  }
  function elementAccessibleLabel(element) {
    return `${element.getAttribute("aria-label") ?? ""} ${element.title ?? ""} ${element.innerText ?? ""}`.trim();
  }
  function imageCandidates(image) {
    const values = [];
    const container = image.closest(".group\\/imagegen-image, [id^='image-'], generated-image, single-image") ?? image.parentElement;
    for (const element of [image, container].filter((el) => Boolean(el))) {
      for (const attribute of ["data-full-size-url", "data-download-url", "data-original-src", "data-src"]) {
        const value = element.getAttribute(attribute);
        if (value) values.push(value);
      }
    }
    for (const anchor of container?.querySelectorAll("a[href]") ?? []) {
      const label = `${anchor.innerText} ${anchor.getAttribute("aria-label") ?? ""} ${anchor.title ?? ""}`;
      if (/download|full size|原图|下载/i.test(label) || /\.(png|jpe?g|webp)(?:\?|$)/i.test(anchor.href)) {
        values.push(anchor.href);
      }
    }
    return [...new Set(values.map((value) => {
      try {
        return new URL(value, location.href).href;
      } catch {
        return value;
      }
    }))].filter((value) => /^(https?:|blob:|data:image\/)/i.test(value));
  }
  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }
  async function report(jobId, status, errorMessage) {
    await sendProgress({ type: "JOB_PROGRESS", jobId, status, errorMessage });
  }
  async function sendProgress(message) {
    await chrome.runtime.sendMessage(message);
  }
  async function traceJob(jobId, stage, data = {}) {
    const message = { type: "JOB_TRACE", jobId, stage, data };
    try {
      await chrome.runtime.sendMessage(message);
    } catch {
    }
  }
  async function debugLog(label, data) {
    try {
      await fetch("http://127.0.0.1:17321/debug-log", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ label, data, href: location.href })
      });
    } catch {
    }
  }
  async function setExpectingNavigation(expecting) {
    try {
      await chrome.runtime.sendMessage({ type: "EXPECT_NAVIGATION", expecting });
    } catch {
    }
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
})();
//# sourceMappingURL=content.js.map
