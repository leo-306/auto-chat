"use strict";
(() => {
  // src/popup.ts
  var server = document.querySelector("#server");
  var extensionVersion = document.querySelector("#extension-version");
  var statusCopy = document.querySelector("#status-copy");
  var pause = document.querySelector("#pause");
  var tick = document.querySelector("#tick");
  var workers = document.querySelector("#workers");
  var workersCopy = document.querySelector("#workers-copy");
  var inspect = document.querySelector("#inspect");
  var debugSuccess = document.querySelector("#debug-success");
  var debugError = document.querySelector("#debug-error");
  var debugStalled = document.querySelector("#debug-stalled");
  var debugTimeout = document.querySelector("#debug-timeout");
  var openTab = document.querySelector("#open-tab");
  var debugOutput = document.querySelector("#debug-output");
  var tabButtons = [...document.querySelectorAll(".tab[data-platform]")];
  var activePlatform = "gpt";
  for (const button of tabButtons) {
    button.addEventListener("click", async () => {
      activePlatform = platformFromButton(button);
      await render();
    });
  }
  pause.addEventListener("click", async () => {
    const state = await getState();
    const platform = state.platforms[activePlatform];
    await chrome.runtime.sendMessage({ type: "SET_PAUSED", platform: activePlatform, paused: !platform.paused });
    await render();
  });
  tick.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "TICK", platform: activePlatform });
    await render();
  });
  inspect.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_INSPECT_CURRENT_TAB", platform: activePlatform });
  });
  debugSuccess.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_SIMULATE_SUCCESS", platform: activePlatform });
  });
  debugError.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_SIMULATE_ERROR", platform: activePlatform });
  });
  debugStalled.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_SIMULATE_STALLED", platform: activePlatform });
  });
  debugTimeout.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_SIMULATE_TIMEOUT", platform: activePlatform });
  });
  openTab.addEventListener("click", async () => {
    await runDebug({ type: "DEBUG_OPEN_ACTIVE_TAB", platform: activePlatform });
  });
  async function getState() {
    return chrome.runtime.sendMessage({ type: "GET_STATE", platform: activePlatform });
  }
  async function render() {
    const state = await getState();
    const platform = state.platforms[activePlatform];
    for (const button of tabButtons) {
      button.classList.toggle("active", platformFromButton(button) === activePlatform);
    }
    server.textContent = state.serverOk ? "\u670D\u52A1\u5728\u7EBF" : "\u670D\u52A1\u79BB\u7EBF";
    server.className = `status-pill ${state.serverOk ? "ok" : "off"}`;
    extensionVersion.textContent = `v${state.extensionVersion}`;
    statusCopy.textContent = statusMessage(state, platform);
    pause.textContent = platform.paused ? "\u5F00\u542F\u81EA\u52A8\u6267\u884C" : "\u6682\u505C\u81EA\u52A8\u6267\u884C";
    tick.disabled = !state.serverOk;
    pause.disabled = !state.serverOk;
    openTab.disabled = platform.workers.length === 0;
    workersCopy.textContent = `\u5F53\u524D\u7531\u63D2\u4EF6\u63A5\u7BA1\u7684 ${platformLabel(activePlatform)} \u6807\u7B7E\u9875\u548C\u4EFB\u52A1\u3002`;
    debugOutput.textContent = platform.lastDebug || (state.serverOk ? `\u672C\u5730\u670D\u52A1\u5DF2\u8FDE\u63A5\u3002\u8FD0\u884C auto-chat add <job.json> --platform ${activePlatform} \u521B\u5EFA\u4EFB\u52A1\u3002` : "\u672C\u5730\u670D\u52A1\u672A\u8FDE\u63A5\uFF1A\u8BF7\u5148\u8FD0\u884C auto-chat start\u3002");
    workers.innerHTML = platform.workers.length ? platform.workers.map((worker) => `
      <div class="worker">
        <div class="worker-title">${escapeHtml(worker.jobId)}</div>
        <div class="worker-meta">
          <span>${platformLabel(worker.platform)} \u6807\u7B7E\u9875 ${worker.tabId}</span>
          <span>\u5DF2\u5237\u65B0 ${worker.refreshCount} \u6B21</span>
        </div>
      </div>
    `).join("") : `<div class="empty">\u5F53\u524D\u6CA1\u6709\u6B63\u5728\u6267\u884C\u7684 ${platformLabel(activePlatform)} \u4EFB\u52A1\u3002\u53EF\u8FD0\u884C auto-chat dispatch --platform ${activePlatform} \u89E6\u53D1\u4E00\u6B21\u8C03\u5EA6\u3002</div>`;
  }
  async function runDebug(message) {
    const response = await chrome.runtime.sendMessage(message);
    debugOutput.textContent = JSON.stringify(response, null, 2);
    await render();
  }
  function escapeHtml(value) {
    return value.replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[char]);
  }
  function statusMessage(state, platform) {
    if (!state.serverOk) return "\u672C\u5730\u670D\u52A1\u672A\u8FDE\u63A5\uFF1A\u8BF7\u5148\u8FD0\u884C auto-chat start\u3002";
    if (platform.workers.length > 0) return `${platformLabel(activePlatform)} \u6B63\u5728\u5904\u7406 ${platform.workers.length} \u4E2A\u4EFB\u52A1\u3002`;
    return platform.paused ? `${platformLabel(activePlatform)} \u81EA\u52A8\u6267\u884C\u5DF2\u6682\u505C\uFF1B\u70B9\u51FB\u201C\u6267\u884C\u4E00\u6B21\u8C03\u5EA6\u201D\u53EA\u9886\u53D6\u4E00\u8F6E\u4EFB\u52A1\u3002` : `${platformLabel(activePlatform)} \u81EA\u52A8\u6267\u884C\u5DF2\u5F00\u542F\uFF1B\u63D2\u4EF6\u4F1A\u6301\u7EED\u9886\u53D6\u8BE5\u5E73\u53F0\u961F\u5217\u4E2D\u7684\u4EFB\u52A1\u3002`;
  }
  function platformFromButton(button) {
    if (button.dataset.platform === "gemini" || button.dataset.platform === "doubao") return button.dataset.platform;
    return "gpt";
  }
  function platformLabel(platform) {
    if (platform === "gemini") return "Gemini";
    if (platform === "doubao") return "\u8C46\u5305";
    return "GPT";
  }
  render();
  setInterval(render, 2e3);
})();
//# sourceMappingURL=popup.js.map
